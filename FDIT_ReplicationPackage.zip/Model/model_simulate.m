function [sim,r,s] = model_simulate(m,s,r)
%% Stationary measure across states

[sim.measure,r,s] = stationary_measure(m,s,r);   

%% Aggregates

%Capital
    sim.K = sum(sum(sum(sim.measure.*r.k)));
    sim.A = sum(sum(sum(sim.measure.*r.a))); 
    
%Consumption
    sim.C = sum(sum(sum(sim.measure.*r.c))); 

%Fixed costs   
    %Exports
        sim.X_fc = sum(sum(squeeze(sim.measure(1,:,:).*r.e(1,:,:)).*m.S_mat)) + sum(sum(sum(sim.measure.*r.e.*r.X_Fcost_total)));
        
    %Occupation
        sim.E_fc = 0;
        for i=1:s.m_grid_size
            sim.E_fc = sim.E_fc + sum(sum(sum(sim.measure(r.m==i+1))))*m.M1_vec(i);
        end

%Labor 
    sim.N_T_production  = sum(sum(sum(sim.measure.*r.n)));
    sim.N_T             = sim.N_T_production + sim.X_fc + sim.E_fc;
    sim.Ns              = sum(sum(sum(sim.measure.*r.worker)));

%% Prices

%Sectoral goods
    %Prices of sectoral goods
        sim.Pm = m.Pm_vec;

        for i=1:s.m_grid_size        
            sim.Psect_sigma_vec(i)  = sum(sum(sum( sim.measure(r.m==i+1).*(r.ph(r.m==i+1).^(1-m.sigma_vec(i))) )));

            sim.Psect_vec(i)        = (m.omega_m_vec(i)^(m.sigma_vec(i))) * (m.Pm_vec(i)^(1-m.sigma_vec(i)));
            if sim.Psect_sigma_vec(i)>0
                sim.Psect_vec(i) = sim.Psect_vec(i) + ((m.omega_h_sec_vec(i))^m.sigma_vec(i)) *sim.Psect_sigma_vec(i);
            end
            sim.Psect_vec(i) = sim.Psect_vec(i).^(1/(1-m.sigma_vec(i)));  
        end    

%Price of non-tradable goods
    NTprice_z = (1/m.z_NT);

    NTprice_wage = (m.w/(1-m.phi_int_vec(s.m_grid_size+1)))^(1-m.phi_int_vec(s.m_grid_size+1));

    NTprice_int = 1;
    for k=1:s.m_grid_size
        NTprice_int = NTprice_int * ((sim.Psect_vec(k)/(m.phi_int_vec(s.m_grid_size+1)*m.gamma_mat(k,s.m_grid_size+1))).^m.gamma_mat(k,s.m_grid_size+1));
    end
    NTprice_int = NTprice_int.^m.phi_int_vec(s.m_grid_size+1);
    
    Ntprice_const = (1/(m.phi_int_vec(s.m_grid_size+1)*m.gamma_mat(s.m_grid_size+1,s.m_grid_size+1)))^(m.phi_int_vec(s.m_grid_size+1)*m.gamma_mat(s.m_grid_size+1,s.m_grid_size+1));
        
    sim.P_NT = (Ntprice_const .* NTprice_z .* NTprice_wage .* NTprice_int).^(1/(1-m.phi_int_vec(s.m_grid_size+1)*m.gamma_mat(s.m_grid_size+1,s.m_grid_size+1)));   
    sim.P_NT = (1+m.r*(1-m.theta_wc))*sim.P_NT;
    sim.Psect_vec(s.m_grid_size+1) = sim.P_NT;   
    
%Final good price
    sim.P = 1;
    for i=1:s.m_grid_size+1
       sim.P = sim.P * ((sim.Psect_vec(i)/m.phi_fin_vec(i))^m.phi_fin_vec(i)); 
    end     
    sim.P = sim.P^(1/sum(m.phi_fin_vec));          
              
%% Price of intermediate inputs

for i=1:s.m_grid_size+1
    sim.Pint_vec(i,1) = 1;
    for j=1:s.m_grid_size+1
        sim.Pint_vec(i,1) = sim.Pint_vec(i,1)*((sim.Psect_vec(j)/m.gamma_mat(j,i))^m.gamma_mat(j,i));
    end
end

%% Supply of goods
    
%Tradables
    sim.Ym = (m.omega_m_vec.^m.sigma_vec) .* m.Ysect_vec(1:s.m_grid_size) .* ((sim.Pm./sim.Psect_vec(1:s.m_grid_size)).^(-m.sigma_vec));   

    for i=1:s.m_grid_size        
        sim.Ysect_vec(i)        = m.omega_m_vec(i)*(sim.Ym(i).^((m.sigma_vec(i)-1)/m.sigma_vec(i)));
        if sim.Psect_sigma_vec(i)>0
            sim.Ysect_vec(i) = sim.Ysect_vec(i) + (m.omega_h_sec_vec(i))*sum(sum(sum( sim.measure(r.m==i+1).*(r.yh(r.m==i+1).^((m.sigma_vec(i)-1)/m.sigma_vec(i))) )));
        end
        sim.Ysect_vec(i) = sim.Ysect_vec(i).^(m.sigma_vec(i)/(m.sigma_vec(i)-1));   
    end

%Non-tradables      
    %Labor
    %Solve using labor market clearing condition
        sim.N_NT = max(sim.Ns - sim.N_T,0); 

    %Output
        sim.Y_NT = (1+m.r*(1-m.theta_wc))*m.w*sim.N_NT/(sim.P_NT*(1-m.phi_int_vec(s.m_grid_size+1)));
        sim.Ysect_vec(s.m_grid_size+1) = sim.Y_NT;   
        
    %Intermediates
        NTint = zeros(1,s.m_grid_size+1);
        for k=1:s.m_grid_size
           NTint(k) = m.phi_int_vec(s.m_grid_size+1)*m.gamma_mat(k,s.m_grid_size+1)*sim.P_NT*sim.Y_NT/(m.Psect_vec(k)*(1+m.r*(1-m.theta_wc)));
        end
        NTint(s.m_grid_size+1) = m.phi_int_vec(s.m_grid_size+1)*m.gamma_mat(s.m_grid_size+1,s.m_grid_size+1)*sim.P_NT*sim.Y_NT/(sim.P_NT*(1+m.r*(1-m.theta_wc)));
        sim.h_NT = NTint;        
        sim.h_NT_value = m.Psect_vec*sim.h_NT';
        
%Final goods        
    %Sectoral goods not used for intermediates
        for k=1:s.m_grid_size+1
            sim.intermediates(k) = sum(sum(sum(sim.measure.*r.h(:,:,:,k)))) + sim.h_NT(k);         
            sim.Ysect_fin_vec(k) = max(sim.Ysect_vec(k) - sim.intermediates(k),1e-16); %Production of sectoral goods = Use as intermediates + Use as final goods
        end

    %Output
        sim.Y = 1;
        for i=1:s.m_grid_size+1
            sim.Y = sim.Y * (sim.Ysect_fin_vec(i)^m.phi_fin_vec(i));
        end

%% Demand for goods

temp = max(0,m.w*sim.N_NT/sim.P)*(m.r*(1-m.theta_wc)) + max(0,sim.h_NT_value/sim.P*(m.r*(1-m.theta_wc)));

for i=1:s.m_grid_size+1
    sim.Ysect_final_demand(i)   = m.phi_fin_vec(i)*sim.P*(sim.C + m.delta*sim.K + temp)/sim.Psect_vec(i); %This equation uses MCC for final goods
    sim.Ysect_int_demand(i)     = sim.h_NT(i) + sum(sum(sum(sim.measure.*r.h(:,:,:,i))));
    sim.Ysect_demand(i)         = sim.Ysect_final_demand(i) + sim.Ysect_int_demand(i);
end

%% Policy functions used to compute statistics
    
%Labor
    r.n_total = r.n;
    r.n_total(1,:,:)    = r.n_total(1,:,:) + r.e(1,:,:).*m.Scost;
    r.n_total           = r.n_total + r.e.*r.X_Fcost_total;
    for i=1:s.m_grid_size
        r.n_total(r.m==i+1) = r.n_total(r.m==i+1) + m.M1_vec(i);        
    end
 
%Sales    
    r.sales   = r.ph.*r.yh + r.pfyf_total;
    r.sales_f = r.pfyf_total;
    r.sales_h = r.ph.*r.yh;    
    
    r.VA = r.sales;
    for j=1:s.m_grid_size+1
       r.VA = r.VA - m.Psect_vec(j)*r.h(:,:,:,j); 
    end
    
%Export intensity
    r.xshare = r.sales_f./r.sales;
    
%Debt
    r.d = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size);
    
    %Worker
        r.d(r.m==1) = -r.a(r.m==1)*(1+m.r);
        
    %Entrepreneur
        r.d(r.m~=1) = r.k(r.m~=1) + m.eta_F*(m.w/m.P)*r.X_Fcost_total(r.m~=1) - r.a(r.m~=1);
        r.d(r.m(1,:,:)~=1) = r.d(r.m(1,:,:)~=1) + m.eta_S*(m.w/m.P)*m.Scost.*r.e(r.m(1,:,:)~=1);
        for i=1:s.m_grid_size   
            r.d(r.m==i+1) = r.d(r.m==i+1) + (m.w/m.P)*m.eta_M*m.M1_vec(i);
        end
        r.d(r.m~=1) = r.d(r.m~=1)*(1+m.r);
            
    %Nominal
        r.d_nominal = m.P*r.d;
    
%Capital per worker
    r.k_n = m.P*r.k./r.n_total;
    
%% Distribution of agents

%Workers vs. firms
    sim.allagents_share_workers = sum(sum(sum(sim.measure(r.m==1))));
    sim.allagents_share_firms   = sum(sum(sum(sim.measure(r.m~=1))));

%High vs. low    
    for i=1:s.m_grid_size
        sim.allfirms_share_vec(i) = sum(sum(sum(sim.measure(r.m==i+1))))/sim.allagents_share_firms;    
    end
    if sim.allagents_share_firms==0
        sim.allfirms_share_vec(1:s.m_grid_size) = 0;
    end          

%Exporters vs. non-exporters
    sim.allfirms_share_x  = sum(sum(sum(sim.measure(r.e==1 & r.m~=1))))/sim.allagents_share_firms; 
    sim.allfirms_share_nx = sum(sum(sum(sim.measure(r.e==0 & r.m~=1))))/sim.allagents_share_firms;
    if sim.allagents_share_firms==0
        sim.allfirms_share_x  = 0;
        sim.allfirms_share_nx = 0;
    end                
    sim.allagents_share_x = sum(sum(sum(sim.measure(r.e==1))));

%Exporters vs. non-exporters, by type of firm
    for i=1:s.m_grid_size
        sim.firms_share_x_vec(i)  = sum(sum(sum(sim.measure(r.e==1 & r.m==i+1))))/sum(sum(sum(sim.measure(r.m==i+1))));
        sim.firms_share_nx_vec(i) = sum(sum(sum(sim.measure(r.e==0 & r.m==i+1))))/sum(sum(sum(sim.measure(r.m==i+1))));
    end

%% Aggregate variables

%Non-tradables
    sim.TotalLabor  = sim.N_NT + sim.N_T;
    sim.Workers_NT  = sim.N_NT/sim.TotalLabor;
    sim.Workers_T   = sim.N_T/sim.TotalLabor;

%Level
    %Domestic sales, exports, and imports
        sim.X          = sum(sum(sum(sim.measure(r.sales_f>0).*r.sales_f(r.sales_f>0))));  
        sim.D          = sum(sum(sum(sim.measure(r.sales_h>0).*r.sales_h(r.sales_h>0))));  
        sim.M          = sum(sim.Pm.*sim.Ym);

    %GDP and total sales
        sim.GDP = sim.D + sim.X;
        for j=1:s.m_grid_size+1
            sim.GDP = sim.GDP - m.Psect_vec(j)*sum(sum(sum(sim.measure.*r.h(:,:,:,j))));
        end
        
        sim.TotalSales = sim.D + sim.X;

        sim.GDP_agg = sim.GDP + sim.Psect_vec(s.m_grid_size+1)*sim.Ysect_vec(s.m_grid_size+1) - sim.Psect_vec*sim.h_NT';
        
    %Net exports
        sim.NX         = sim.X - sim.M;

    %Credit
        sim.ncredit    = sum(sum(sum(sim.measure.*max(r.d_nominal,0)))); 

    %Debt
        sim.debt = sum(sum(sum(sim.measure.*r.d))); 
        
%Ratios
    %Exports
        sim.X_D          = sim.X/sim.D;
        sim.X_GDP        = sim.X/sim.GDP;
        sim.X_TotalSales = sim.X/sim.TotalSales; 

    %Imports
        sim.M_GDP        = sim.M/sim.GDP;
        sim.M_TotalSales = sim.M/sim.TotalSales;
        sim.M_Abs        = sim.M/(sim.P*sim.Y);           
        
    %Net exports/GDP
        sim.NX_GDP           = sim.NX/sim.GDP; 
        sim.NX_GDP_Aggregate = sim.NX/sim.GDP_agg;
        
    %Credit/GDP
        sim.ncredit_GDP         = sim.ncredit/sim.GDP; 
        sim.ncredit_TotalSales  = sim.ncredit/sim.TotalSales;    
        
    %Capital/WageBill
        sim.K_wagebill_ratio                = (m.P*sim.K)/(m.w*sim.N_T_production);    
        sim.K_wagebill_ratio_withfixedcosts = (m.P*sim.K)/(m.w*sim.N_T);  
        sim.Kshare = (m.P*(m.r+m.delta)*sim.K)/(m.P*(m.r+m.delta)*sim.K+m.w*sim.N_T_production);
        
    %Capital/Labor (tradables)
        sim.kn_agg_all = m.P*sum(sim.measure(r.m~=1).*r.k(r.m~=1))/sum(sim.measure(r.m~=1).*r.n_total(r.m~=1));
                        
    %Absorption/WorldGDP
        sim.Abs_WorldGDP = (sim.P*sim.Y)/(m.Prow*m.Yrow);        
            
%RER
    sim.RER = m.Prow/m.P;               
    
%% Sectoral aggregates    
    
%Levels
    %Production and sales
        for i=1:s.m_grid_size    
           sim.X_vec(i)          = sum(sum(sum(sim.measure(r.m==i+1).*r.sales_f(r.m==i+1))));
           sim.D_vec(i)          = sum(sum(sum(sim.measure(r.m==i+1).*r.sales_h(r.m==i+1))));        
           
           sim.GDP_vec(i) = sum(sum(sum(sim.measure(r.m==i+1).*r.sales(  r.m==i+1))));
           for j=1:s.m_grid_size+1
               temp = squeeze(r.h(:,:,:,j));
               sim.GDP_vec(i) = sim.GDP_vec(i) - m.Psect_vec(j)*sum(sum(sum(sim.measure(r.m==i+1).*temp(r.m==i+1)))); 
           end
           
           sim.TotalSales_vec(i) = sum(sum(sum(sim.measure(r.m==i+1).*r.sales(  r.m==i+1))));                             
        end         
    
%Ratios        
    %Exports
        for i=1:s.m_grid_size
            sim.XD_vec(i) = sum(sum(sum(sim.measure(r.m==i+1).*r.sales_f(r.m==i+1))))./sum(sum(sum(sim.measure(r.m==i+1).*r.sales_h(r.m==i+1))));    
            sim.XY_vec(i) = sum(sum(sum(sim.measure(r.m==i+1).*r.sales_f(r.m==i+1))))./sum(sum(sum(sim.measure(r.m==i+1).*r.sales(r.m==i+1))));    
        end
    
    %Capital/Labor
        for i=1:s.m_grid_size
           sim.kn_agg_vec(i) = m.P*sum(sim.measure(r.m==i+1).*r.k(r.m==i+1))/sum(sim.measure(r.m==i+1).*r.n_total(r.m==i+1)); 
           sim.kshare_vec(i) = m.P*(m.r+m.delta)*sum(sim.measure(r.m==i+1).*r.k(r.m==i+1))/...
                               (m.P*(m.r+m.delta)*sum(sim.measure(r.m==i+1).*r.k(r.m==i+1)) + m.w*sum(sim.measure(r.m==i+1).*r.n(r.m==i+1))); 
        end        
                
%Share of aggregate sales across sectors
    for i=1:s.m_grid_size    
        sim.D_share_vec(i)     = sum(sum(sum(sim.measure(r.m==i+1).*r.sales_h(r.m==i+1))))./sum(sum(sum(sim.measure.*r.sales_h)));
        sim.Sales_share_vec(i) = sum(sum(sum(sim.measure(r.m==i+1).*r.sales(  r.m==i+1))))./sum(sum(sum(sim.measure.*r.sales  )));
    end              

%% Welfare    
    
%Welfare
    sim.welfare         = sum(sum(sum(sim.measure.*r.v)));

%Store value function and occupation/exporting policies
    sim.v = r.v;
    sim.m = r.m;
    sim.e = r.e;
    
%% Firm-level statistics

%Average export intensity
    sim.xshare_avg = sum(sim.measure(r.m~=1 & r.e==1).*r.xshare(r.m~=1 & r.e==1))/sum(sim.measure(r.m~=1 & r.e==1));        
    
%Exporter sales premium
	sim.Xsales_NXsales = (sum(sum(sum(sim.measure(r.e==1 & r.m~=1).*r.sales(r.e==1 & r.m~=1))))/sum(sum(sum(sim.measure(r.e==1 & r.m~=1)))))/...
						 (sum(sum(sum(sim.measure(r.e==0 & r.m~=1).*r.sales(r.e==0 & r.m~=1))))/sum(sum(sum(sim.measure(r.e==0 & r.m~=1)))));                         
    if isempty(sim.Xsales_NXsales)==1
        sim.Xsales_NXsales = 1000;      
    elseif isfinite(sim.Xsales_NXsales)==0
        sim.Xsales_NXsales = 1000;
    end           
                
%Export exit rate conditional on continuing to produce for the domestic market
    sim.xexit_rate = sum(sum(sim.measure(2,:,:).*(1-r.e(2,:,:)).*(r.m(2,:,:)~=1)))/sum(sum(sim.measure(2,:,:).*(r.m(2,:,:)~=1)));
    if isempty(sim.xexit_rate)==1
        sim.xexit_rate = 1000;        
    elseif isfinite(sim.xexit_rate)==0
        sim.xexit_rate = 1000;
    end            
      
%Export entry rate conditional on producing domestically
    sim.xentry_rate = sum(sum(sim.measure(1,:,:).*(r.e(1,:,:)).*(r.m(1,:,:)~=1)))/sum(sum(sim.measure(1,:,:).*(r.m(1,:,:)~=1)));
    if isempty(sim.xexit_rate)==1
        sim.xentry_rate = 1000;        
    elseif isfinite(sim.xexit_rate)==0
        sim.xentry_rate = 1000;
    end       
  
%Exit rate    
    if s.simulate_sm_shocks==1 && s.extraresults>=1 
        sim.exit_rate_firms = 0;
        for j=1:s.z_grid_size       %Current productivity
            for jj=1:s.z_grid_size  %Next period's productivity
                for k=1:2           %Current export status
                    %Sum mass of current firms that are not firms next period
                    sim.exit_rate_firms = sim.exit_rate_firms + sum( (r.m(k,:,j)~=1) .*...
                                          (r.m(sub2ind(size(sim.measure),squeeze(r.e(k,:,j))+1,squeeze(r.ap_ind(k,:,j)),jj*ones(1,s.a_grid_size)))==1) .*...
                                          sim.measure(k,:,j)*r.z_P(j,jj)); 
                end
            end
        end
        sim.exit_rate_firms = sim.exit_rate_firms / sim.allagents_share_firms;
        if isempty(sim.exit_rate_firms)==1
            sim.exit_rate_firms = 1000;   
        elseif isfinite(sim.exit_rate_firms)==0
            sim.exit_rate_firms = 1000;
        end     
    else
        sim.exit_rate_firms = 1000;
    end

%Median capital per worker    
    %By sector
        for i=1:s.m_grid_size
            [kn_sorted,kn_sorted_ind] = sort(r.k_n(r.m==i+1));
            measure_sorted = sim.measure(r.m==i+1);
            measure_sorted = measure_sorted(kn_sorted_ind)/sum(measure_sorted);
            kn_med_ind = find(cumsum(measure_sorted)>=0.50,1,'first');
            if isempty(kn_med_ind)==0
                sim.kn_med_vec(i) = kn_sorted(kn_med_ind);
            else
                sim.kn_med_vec(i) = 0;
            end
        end
   
    %Ratio of highest to lowest sector
        sim.kn_med_HtoLratio = sim.kn_med_vec(end)/sim.kn_med_vec(1);
        if isempty(sim.kn_med_HtoLratio)==1 
            sim.kn_med_HtoLratio = 1000;            
        elseif isfinite(sim.kn_med_HtoLratio)==0
            sim.kn_med_HtoLratio = 1000;  
        end            
        
        sim.kn_med_MtoLratio = sim.kn_med_vec(2)/sim.kn_med_vec(1);
        if isempty(sim.kn_med_MtoLratio)==1 
            sim.kn_med_MtoLratio = 1000;            
        elseif isfinite(sim.kn_med_MtoLratio)==0
            sim.kn_med_MtoLratio = 1000;  
        end          
        
    %Economy-wide
        [kn_all_sorted,kn_all_sorted_ind] = sort(r.k_n(r.m~=1));
        measure_all_sorted = sim.measure(r.m~=1);
        measure_all_sorted = measure_all_sorted(kn_all_sorted_ind)/sum(measure_all_sorted);
        kn_all_med_ind = find(cumsum(measure_all_sorted)>=0.50,1,'first');
        sim.kn_med_all = kn_all_sorted(kn_all_med_ind);              
        
%Median workers per firm        
    for i=1:s.m_grid_size
        [n_sorted,n_sorted_ind] = sort(r.n_total(r.m==i+1));
        measure_sorted = sim.measure(r.m==i+1);
        measure_sorted = measure_sorted(n_sorted_ind)/sum(measure_sorted);
        n_med_ind = find(cumsum(measure_sorted)>=0.50,1,'first');
        if isempty(n_med_ind)==0
            sim.n_med_vec(i) = n_sorted(n_med_ind);
        else
            sim.n_med_vec(i) = 0;
        end
    end

    %Ratio of highest to lowest sector
        sim.n_med_HtoLratio = sim.n_med_vec(end)/sim.n_med_vec(1);
        if isempty(sim.n_med_HtoLratio)==1 
            sim.n_med_HtoLratio = 1000;            
        elseif isfinite(sim.n_med_HtoLratio)==0
            sim.n_med_HtoLratio = 1000;  
        end        
        
%% Multiple-country statistics

if m.X_countries>1
    for j=1:m.X_countries
        sim.X_countries(j,1)                  = sum(sum(sum(sim.measure.*squeeze(r.pf(:,:,:,j).*r.yf(:,:,:,j)))));
        sim.Xshare_countries(j,1)             = sum(sum(sum(sim.measure.*squeeze(r.pf(:,:,:,j).*r.yf(:,:,:,j)))))./sim.X;   
        
        sim.allagents_countries(j,1)          = sum(sim.measure(r.m~=1 & squeeze(r.yf(:,:,:,j))~=0));
        sim.allfirms_share_countries(j,1)     = sim.allagents_countries(j,1)/sim.allagents_share_firms;
        sim.allexporters_share_countries(j,1) = sim.allagents_countries(j,1)/sim.allagents_share_x;
        
        sim.Abs_DestinationGDP(j) = (sim.P*sim.Y)/(m.X_Prow(j)*m.X_Yrow(j));
    end
end

%% Solution-related statistics

%Productivity
    sim.z_avg = sum(sum(sum(sim.measure.*r.z)));

    sim.z_threshold_worker = zeros(s.a_grid_size,2);
    for i=1:s.a_grid_size   
        for k=1:2      
            if sum(squeeze(r.worker(k,i,:))==1)==0
                sim.z_threshold_worker(i,k) = 0;
            else
                sim.z_threshold_worker(i,k) = find(squeeze(r.worker(k,i,:))==1,1,'last');
            end
        end
    end
    sim.z_gridpoints_worker = mean(sim.z_threshold_worker(:))/s.z_grid_size;

%Net worth
    sim.a_min_share = sum(sum(sim.measure(:,1,:)));
    sim.a_max_share = sum(sum(sim.measure(:,end,:)));
    if m.nu>0
        sim.a_init_share = sum(sum(sim.measure(:,m.a_new,:)));
    end

    sim.a_min_share_firms = sum(sum(sim.measure(:,1,:).*(1-r.worker(:,1,:))))/sim.allagents_share_firms;
    sim.a_max_share_firms = sum(sum(sim.measure(:,end,:).*(1-r.worker(:,end,:))))/sim.allagents_share_firms;
    if m.nu>0
        sim.a_init_share_firms = sum(sum(sim.measure(:,m.a_new,:).*(1-r.worker(:,m.a_new,:))))/sim.allagents_share_firms;
    end

    sim.a_min_share_workers = sum(sum(sim.measure(:,1,:).*r.worker(:,1,:)))/sim.allagents_share_workers;
    sim.a_max_share_workers = sum(sum(sim.measure(:,end,:).*r.worker(:,end,:)))/sim.allagents_share_workers;
    if m.nu>0
        sim.a_init_share_workers = sum(sum(sim.measure(:,m.a_new,:).*r.worker(:,m.a_new,:)))/sim.allagents_share_workers;
    end

%% Draw random sample

if s.simulate_sm_shocks==1 && s.extraresults>=1 

    for iter_k=1:s.K2

        %Number of periods to simulated before burning
            T2_preburn = s.T2 + s.T2_burn;

        %Initial distribution                
            %Set seed for randomization
                RandStream.setGlobalStream(RandStream('mt19937ar','seed',s.seed+iter_k)); 
                
            %CDF of stationary measure, ordering states according to indexes
                measure_cumsum = cumsum(sim.measure(:))';            
                
            %For each agent, draw random number from Uniform~[0,1]
                firms = rand(s.N2,1);                                         
                
            %Index for each agent's state = # of states for which random number is higher than CDF  
                ind = sum(firms>measure_cumsum,2) + 1;      
                
            %Map scalar index into 3-dimensional index
                [ind_e,ind_a,ind_z] = ind2sub(size(sim.measure),ind);

        %Subsequent periods    
            %Productivity
                %For each row, compute CDF of transition matrix
                    C = cumsum(r.z_P,2);
                
                %For each (agent,period) draw random number from Uniform~[0,1]
                    R = rand(s.N2,T2_preburn);
                    
                %For each (agent,period), set productivity index to equal = # of productivity indexes such that 
                %random number higher than CDF conditional on previous period's productivity
                    for j=2:T2_preburn
                        f          = repmat(R(:,j),1,s.z_grid_size);
                        ind_z(:,j) = 1 + sum(f>C(ind_z(:,j-1),:),2);
                        clear f;
                    end
                    clear R C;   

            %New agents     
                new = zeros(s.N2,T2_preburn);
                if sum(m.nu_z_grid)>0
                    for t=2:T2_preburn
                        for j=1:s.z_grid_size
                            %Find index of agents in period t with productivity index j
                                temp     = find(ind_z(:,t)==j);
                                temp_num = numel(temp);

                            %New individuals = Random subset from temp of length round(m.nu_z_grid(j)*temp_num                       
                                new_indiv = temp(randperm(temp_num,round(m.nu_z_grid(j)*temp_num)));

                            %Matrix indicating new individuals
                                new(new_indiv,t) = 1;
                        end
                    end
                end                         
                    
            %Net worth and exports
                for t=2:T2_preburn                        
                    %Continuing individuals
                        ind_a(:,t) = r.ap_ind(ind(:,t-1));
                        ind_e(:,t) = r.e(ind(:,t-1)) + 1;
                    
                    %Initialize new individuals without net worth and as never exporters
                        ind_a(new(:,t)==1,t) = 1;
                        ind_e(new(:,t)==1,t) = 1;
                    
                    %Map 3-dimensional index into scalar index
                        ind(:,t)   = sub2ind(size(sim.measure),ind_e(:,t),ind_a(:,t),ind_z(:,t)); 
                end
 
        %Variables
            %Occupation
                m_status = r.m(ind);

            %Firms' age
                age_firms = zeros(s.N2,T2_preburn);
                for t=2:T2_preburn
                    %New firms = (Previous worker or new individual) & current firm
                        age_firms((m_status(:,t-1)==1 | new(:,t)==1) & m_status(:,t)~=1,t) = 1;
                        
                    %Continuing firms = Previous firm & continuing individual & current firm & age not zero
                    %If age is zero, we keep the age at zero => These are the initial firms, for which we don't know their age
                        age_firms(m_status(:,t-1)~=1 & m_status(:,t)~=1 & new(:,t)~=1 & age_firms(:,t-1)~=0,t) = age_firms(m_status(:,t-1)~=1 & m_status(:,t)~=1 & new(:,t)~=1 & ...
                                                                                                                 age_firms(:,t-1)~=0,t-1) + 1;
                end           
    
        %Burn
            ind_e     = ind_e(    :,(end-s.T2)+1:end);
            ind       = ind(      :,(end-s.T2)+1:end);          
            m_status  = m_status( :,(end-s.T2)+1:end);  
            age_firms = age_firms(:,(end-s.T2)+1:end);  

        %Variables
            sales    = r.sales(ind);
            sales_f  = r.sales_f(ind);
            sales_h  = r.sales_h(ind);
            exporter = r.e(ind);
            k        = r.k(ind);
            n_total  = r.n_total(ind);
            pi       = r.pi(ind);            
            
            exporter_lastperiod = ind_e - 1;               

            %Log
                ln_sales = log(sales);
                ln_n     = log(n_total);            
                ln_k     = log(m.P*k);              
            
            %Growth
                dln_sales   = log(sales(:,2:end))       - log(sales(:,1:end-1));
                dln_n       = log(n_total(:,2:end))     - log(n_total(:,1:end-1));
                dln_k       = log(k(:,2:end))           - log(k(:,1:end-1));                
                
        %Statistics            
            %Average sales by age conditional on survival to age 5
                sales_age1 = zeros(s.N2,s.T2);
                sales_age2 = zeros(s.N2,s.T2);
                sales_age5 = zeros(s.N2,s.T2);     
                for t=1:s.T2-4
                    sales_age1(age_firms(:,t)==1 & age_firms(:,t+4)==5,t)   = sales(age_firms(:,t)==1 & age_firms(:,t+4)==5,t);
                    sales_age2(age_firms(:,t)==1 & age_firms(:,t+4)==5,t+1) = sales(age_firms(:,t)==1 & age_firms(:,t+4)==5,t+1);
                    sales_age5(age_firms(:,t)==1 & age_firms(:,t+4)==5,t+4) = sales(age_firms(:,t)==1 & age_firms(:,t+4)==5,t+4);
                end
                                
                %Avg sales at age 5/Avg sales at age 1, conditional on survival to age 5               
                    sim.avg_sales_age5_age1(iter_k,1) = mean(sales_age5(sales_age5~=0))/mean(sales_age1(sales_age1~=0)); 
                    
                %Avg sales at age 5/Avg sales at age 1, unconditional
                    sim.avg_sales_age5_age1_unconditional(iter_k,1) = mean(sales(age_firms==5))/mean(sales(age_firms==1));

            %Validation statistics - Dispersion    
                %Within-period statistics
                    ln_sales_avg    = zeros(s.T2,1);
                    ln_sales_std    = zeros(s.T2,1);
                    ln_n_avg        = zeros(s.T2,1);
                    ln_n_std        = zeros(s.T2,1);
                    ln_k_avg        = zeros(s.T2,1);
                    ln_k_std        = zeros(s.T2,1);                  
                    for t = 1:s.T2
                        ln_sales_avg(t,1) = mean(ln_sales(m_status(:,t)~=1,t));
                        ln_sales_std(t,1) = mean((ln_sales(m_status(:,t)~=1,t)-ln_sales_avg(t,1)).^2)^(1/2);

                        ln_n_avg(t,1) = mean(ln_n(m_status(:,t)~=1,t));
                        ln_n_std(t,1) = mean((ln_n(m_status(:,t)~=1,t)-ln_n_avg(t,1)).^2)^(1/2);                

                        ln_k_avg(t,1) = mean(ln_k(m_status(:,t)~=1,t));
                        ln_k_std(t,1) = mean((ln_k(m_status(:,t)~=1,t)-ln_k_avg(t,1)).^2)^(1/2);                                                  
                    end           
                
                %Average across periods
                    sim.ln_sales_avg(iter_k,1)  = mean(ln_sales_avg);
                    sim.ln_sales_std(iter_k,1)  = mean(ln_sales_std);
                    sim.ln_n_avg(iter_k,1)      = mean(ln_n_avg);
                    sim.ln_n_std(iter_k,1)      = mean(ln_n_std);
                    sim.ln_k_avg(iter_k,1)      = mean(ln_k_avg);
                    sim.ln_k_std(iter_k,1)      = mean(ln_k_std);                   
                    
            %Validation statistics - Autocorrelation
                %Minimum length of spell to compute autocorrelation
                    ac_periods = 6;

                %Ensure there is only one firm per column
                %To do so, I remove observations after a firm exits
                    firms_age               = age_firms';                     %Transpose to get firms into rows and periods into columns
                    firms_age_diff          = diff(firms_age);                %For each firm, compute age changes
                    firms_age_diff_nonneg   = firms_age_diff>=0;              %Exit of firms indicated by decrease in firms_age
                    potentiallyvalid        = cumprod(firms_age_diff_nonneg); %Keeps track of consecutive observations with positive age change

                %Sales
                    ln_sales2 = ln_sales;
                    
                    %Set to zero if not finite
                        ln_sales2(isfinite(ln_sales2)==0) = 0; 
                        
                    %Series 1 = Current values
                        acvar_ln_sales = ln_sales2(:,2:end)';
                        
                    %Series 2 = Lagged values
                        acvar_L_ln_sales = ln_sales2(:,1:end-1)';      
                        
                    %For each firm, compute autocorrelations
                        count = 1;
                        for iter_firm=1:s.N2
                            
                            %Identify observations with non-zero values of the series and part of a consecutive spell of valid observations
                                temp = acvar_ln_sales(:,iter_firm)~=0 & acvar_L_ln_sales(:,iter_firm)~=0 & potentiallyvalid(:,iter_firm)==1; 
                           
                            %Compute autocorrelation if firm has sufficiently many observations
                                if sum(temp)>=ac_periods
                                    ac_ln_sales(count,1) = corr(acvar_ln_sales(temp,iter_firm),acvar_L_ln_sales(temp,iter_firm));
                                    count = count + 1;
                                end
                        end
                        
                        %If no firms, set autocorrelation to zero
                            if sim.allagents_share_firms==0
                                ac_ln_sales = 0;
                            end      
                        
                    %Average autocorrelation
                        if exist('ac_ln_sales','var')==1
                            sim.ac_ln_sales(iter_k,1) = nanmean(ac_ln_sales);
                        else
                            sim.ac_ln_sales(iter_k,1) = 999;
                        end

                %Labor
                    ln_n2 = ln_n;
                    
                    %Set to zero if not finite
                        ln_n2(isfinite(ln_n2)==0) = 0; 
                        
                    %Series 1 = Current values    
                        acvar_ln_n = ln_n2(:,2:end)';
                        
                    %Series 2 = Lagged values    
                        acvar_L_ln_n = ln_n2(:,1:end-1)';            
                        
                    %For each firm, compute autocorrelations
                        count = 1;
                        for iter_firm=1:s.N2
                            
                            %Identify observations with non-zero values of the series and part of a consecutive spell of valid observations
                                temp = acvar_ln_n(:,iter_firm)~=0 & acvar_L_ln_n(:,iter_firm)~=0 & potentiallyvalid(:,iter_firm)==1;
                                
                            %Compute autocorrelation if firm has sufficiently many observations                                
                                if sum(temp)>=ac_periods
                                   ac_ln_n(count,1) = corr(acvar_ln_n(temp,iter_firm),acvar_L_ln_n(temp,iter_firm));
                                   count = count + 1;
                                end
                        end
                        
                        %If no firms, set autocorrelation to zero
                            if sim.allagents_share_firms==0
                                ac_ln_n = 0;
                            end                
                            
                    %Average autocorrelation        
                        if exist('ac_ln_n','var')==1
                            sim.ac_ln_n(iter_k,1) = nanmean(ac_ln_n);
                        else
                            sim.ac_ln_n(iter_k,1) = 999;
                        end                            

                %Capital
                    ln_k2 = ln_k;
                    
                    %Set to zero if not finite
                        ln_k2(isfinite(ln_k2)==0) = 0; 
                        
                    %Series 1 = Current values    
                        acvar_ln_k = ln_k2(:,2:end)';
                        
                    %Series 2 = Lagged values    
                        acvar_L_ln_k = ln_k2(:,1:end-1)';          
                        
                    %For each firm, compute autocorrelations    
                        count = 1;
                        for iter_firm=1:s.N2
                            
                            %Identify observations with non-zero values of the series and part of a consecutive spell of valid observations
                                temp = acvar_ln_k(:,iter_firm)~=0 & acvar_L_ln_k(:,iter_firm)~=0 & potentiallyvalid(:,iter_firm)==1;
                                
                            %Compute autocorrelation if firm has sufficiently many observations    
                                if sum(temp)>=ac_periods
                                   ac_ln_k(count,1) = corr(acvar_ln_k(temp,iter_firm),acvar_L_ln_k(temp,iter_firm));
                                   count = count + 1;                   
                                end
                        end
                        
                        %If no firms, set autocorrelation to zero
                            if sim.allagents_share_firms==0
                                ac_ln_k = 0;
                            end
                            
                    %Average autocorrelation
                        if exist('ac_ln_k','var')==1
                            sim.ac_ln_k(iter_k,1) = nanmean(ac_ln_k);
                        else
                            sim.ac_ln_k(iter_k,1) = 999;
                        end                                  

            %Validation statistics - Growth (average and std. deviation)
                dln_sales_avg   = zeros(s.T2-1,1);
                dln_sales_std   = zeros(s.T2-1,1);
                dln_n_avg       = zeros(s.T2-1,1);
                dln_n_std       = zeros(s.T2-1,1);
                dln_k_avg       = zeros(s.T2-1,1);
                dln_k_std       = zeros(s.T2-1,1);                
                for t = 2:s.T2
                    dln_sales_avg(t-1,1) = mean( dln_sales(m_status(:,t)~=1 & m_status(:,t-1)~=1,t-1));
                    dln_sales_std(t-1,1) = mean((dln_sales(m_status(:,t)~=1 & m_status(:,t-1)~=1,t-1)-dln_sales_avg(t-1,1)).^2)^(1/2);            

                    dln_n_avg(t-1,1) = mean( dln_n(m_status(:,t)~=1 & m_status(:,t-1)~=1,t-1));
                    dln_n_std(t-1,1) = mean((dln_n(m_status(:,t)~=1 & m_status(:,t-1)~=1,t-1)-dln_n_avg(t-1,1)).^2)^(1/2);                     

                    dln_k_avg(t-1,1) = mean( dln_k(m_status(:,t)~=1 & m_status(:,t-1)~=1,t-1));
                    dln_k_std(t-1,1) = mean((dln_k(m_status(:,t)~=1 & m_status(:,t-1)~=1,t-1)-dln_k_avg(t-1,1)).^2)^(1/2);                                 
                end
                sim.dln_sales_avg(iter_k,1) = mean(dln_sales_avg);
                sim.dln_sales_std(iter_k,1) = mean(dln_sales_std);
                
                sim.dln_n_avg(iter_k,1)     = mean(dln_n_avg);
                sim.dln_n_std(iter_k,1)     = mean(dln_n_std);
                
                sim.dln_k_avg(iter_k,1)     = mean(dln_k_avg);
                sim.dln_k_std(iter_k,1)     = mean(dln_k_std);

            %Validation statistics - Share of aggregates accounted by young cohorts
                ages1to5_shareagents    = zeros(s.T2,1);
                ages6to10_shareagents   = zeros(s.T2,1);
                ages11plus_shareagents  = zeros(s.T2,1);
                ages1to5_sharefirms     = zeros(s.T2,1);
                ages6to10_sharefirms    = zeros(s.T2,1);
                ages11plus_sharefirms   = zeros(s.T2,1);                
                sales_share_ages1to5    = zeros(s.T2,1);
                sales_share_ages6to10   = zeros(s.T2,1);
                sales_share_ages11plus  = zeros(s.T2,1);
                n_share_ages1to5        = zeros(s.T2,1);
                n_share_ages6to10       = zeros(s.T2,1);
                n_share_ages11plus      = zeros(s.T2,1);
                k_share_ages1to5        = zeros(s.T2,1);
                k_share_ages6to10       = zeros(s.T2,1);
                k_share_ages11plus      = zeros(s.T2,1);                
                for t = 1:s.T2
                    ages1to5_shareagents(t)     = sum(age_firms(:,t)>0 & age_firms(:,t)<=5)/s.N2;
                    ages6to10_shareagents(t)    = sum(age_firms(:,t)>=6 & age_firms(:,t)<=10)/s.N2;
                    ages11plus_shareagents(t)   = sum(age_firms(:,t)>=11)/s.N2;

                    ages1to5_sharefirms(t)      = sum(age_firms(:,t)>0 & age_firms(:,t)<=5)/sum(m_status(:,t)~=1);
                    ages6to10_sharefirms(t)     = sum(age_firms(:,t)>=6 & age_firms(:,t)<=10)/sum(m_status(:,t)~=1);
                    ages11plus_sharefirms(t)    = sum(age_firms(:,t)>=11)/sum(m_status(:,t)~=1);            

                    sales_share_ages1to5(t)     = sum(sales(age_firms(:,t)>0 & age_firms(:,t)<=5,t))/sum(sales(:,t));
                    sales_share_ages6to10(t)    = sum(sales(age_firms(:,t)>=6 & age_firms(:,t)<=10,t))/sum(sales(:,t));
                    sales_share_ages11plus(t)   = sum(sales(age_firms(:,t)>=11,t))/sum(sales(:,t));               

                    n_share_ages1to5(t)         = sum(n_total(age_firms(:,t)>0 & age_firms(:,t)<=5,t))/sum(n_total(:,t));
                    n_share_ages6to10(t)        = sum(n_total(age_firms(:,t)>=6 & age_firms(:,t)<=10,t))/sum(n_total(:,t));
                    n_share_ages11plus(t)       = sum(n_total(age_firms(:,t)>=11,t))/sum(n_total(:,t));                    

                    k_share_ages1to5(t)         = sum(k(age_firms(:,t)>0 & age_firms(:,t)<=5,t))/sum(k(:,t));            
                    k_share_ages6to10(t)        = sum(k(age_firms(:,t)>=6 & age_firms(:,t)<=10,t))/sum(k(:,t));         
                    k_share_ages11plus(t)       = sum(k(age_firms(:,t)>=11,t))/sum(k(:,t));                        
                end
                sim.ages1to5_shareagents(  iter_k,1)    = mean(ages1to5_shareagents);
                sim.ages6to10_shareagents( iter_k,1)    = mean(ages6to10_shareagents);
                sim.ages11plus_shareagents(iter_k,1)    = mean(ages11plus_shareagents);
               
                sim.ages1to5_sharefirms(   iter_k,1)    = mean(ages1to5_sharefirms);
                sim.ages6to10_sharefirms(  iter_k,1)    = mean(ages6to10_sharefirms);
                sim.ages11plus_sharefirms( iter_k,1)    = mean(ages11plus_sharefirms);            
                
                sim.sales_share_ages1to5(  iter_k,1)    = mean(sales_share_ages1to5);
                sim.sales_share_ages6to10( iter_k,1)    = mean(sales_share_ages6to10);
                sim.sales_share_ages11plus(iter_k,1)    = mean(sales_share_ages11plus);

                sim.n_share_ages1to5(      iter_k,1)    = mean(n_share_ages1to5);
                sim.n_share_ages6to10(     iter_k,1)    = mean(n_share_ages6to10);
                sim.n_share_ages11plus(    iter_k,1)    = mean(n_share_ages11plus);
                
                sim.k_share_ages1to5(      iter_k,1)    = mean(k_share_ages1to5);
                sim.k_share_ages6to10(     iter_k,1)    = mean(k_share_ages6to10);
                sim.k_share_ages11plus(    iter_k,1)    = mean(k_share_ages11plus);                                    

            %Validation statistics - Conditional exit rates
                sales_p25 = zeros(s.T2-1,1);
                sales_p50 = zeros(s.T2-1,1);
                sales_p75 = zeros(s.T2-1,1);
                exit_rate_firms_Q1 = zeros(s.T2-1,1);                
                exit_rate_firms_Q2 = zeros(s.T2-1,1);
                exit_rate_firms_Q3 = zeros(s.T2-1,1);
                exit_rate_firms_Q4 = zeros(s.T2-1,1);
                sales_p33 = zeros(s.T2-1,1);
                sales_p66 = zeros(s.T2-1,1);
                exit_rate_firms_AboveP66    = zeros(s.T2-1,1);
                exit_rate_firms_BelowP33    = zeros(s.T2-1,1);
                exit_rate_firms3            = zeros(s.T2-1,1);             
                for t = 1:s.T2-1
                    
                    %Sales percentiles #1
                        sales_p25(t,1) = prctile(sales(m_status(:,t)~=1,t),25);
                        sales_p50(t,1) = prctile(sales(m_status(:,t)~=1,t),50);
                        sales_p75(t,1) = prctile(sales(m_status(:,t)~=1,t),75);                

                        %Firms
                            ind_Q1 = sales(:,t)< sales_p25(t);
                            ind_Q2 = sales(:,t)>=sales_p25(t) & sales(:,t)<sales_p50(t);
                            ind_Q3 = sales(:,t)>=sales_p50(t) & sales(:,t)<sales_p75(t);
                            ind_Q4 = sales(:,t)>=sales_p75(t);

                        %Exit rates conditional on sales percentile      
                            exit_rate_firms_Q1(t,1) = sum(age_firms(ind_Q1,t)>0 & age_firms(ind_Q1,t+1)<=1)/sum(age_firms(ind_Q1,t)>0);
                            exit_rate_firms_Q2(t,1) = sum(age_firms(ind_Q2,t)>0 & age_firms(ind_Q2,t+1)<=1)/sum(age_firms(ind_Q2,t)>0);
                            exit_rate_firms_Q3(t,1) = sum(age_firms(ind_Q3,t)>0 & age_firms(ind_Q3,t+1)<=1)/sum(age_firms(ind_Q3,t)>0);
                            exit_rate_firms_Q4(t,1) = sum(age_firms(ind_Q4,t)>0 & age_firms(ind_Q4,t+1)<=1)/sum(age_firms(ind_Q4,t)>0);
                            if sum(m_status(ind_Q1,t)~=1)==0
                                exit_rate_firms_Q1(t,1) = 1000; %Large number
                            end         
                            if sum(m_status(ind_Q2,t)~=1)==0
                                exit_rate_firms_Q2(t,1) = 1000; %Large number
                            end     
                            if sum(m_status(ind_Q3,t)~=1)==0
                                exit_rate_firms_Q3(t,1) = 1000; %Large number
                            end     
                            if sum(m_status(ind_Q4,t)~=1)==0
                                exit_rate_firms_Q4(t,1) = 1000; %Large number
                            end                                 
                            
                    %Sales percentiles #2
                        sales_p33(t,1) = prctile(sales(m_status(:,t)~=1,t),33);
                        sales_p66(t,1) = prctile(sales(m_status(:,t)~=1,t),66);

                        %Firms
                            ind_BelowP33 = sales(:,t)< sales_p33(t);
                            ind_AboveP66 = sales(:,t)>=sales_p66(t);
                            
                        %Exit rates conditional on sales percentile      
                            exit_rate_firms_BelowP33(t,1) = sum(age_firms(ind_BelowP33,t)>0 & age_firms(ind_BelowP33,t+1)<=1)/sum(age_firms(ind_BelowP33,t)>0);
                            exit_rate_firms_AboveP66(t,1) = sum(age_firms(ind_AboveP66,t)>0 & age_firms(ind_AboveP66,t+1)<=1)/sum(age_firms(ind_AboveP66,t)>0);              
                            if sum(m_status(ind_BelowP33,t)~=1)==0
                                exit_rate_firms_BelowP33(t,1) = 1000; %Large number
                            end         
                            if sum(m_status(ind_AboveP66,t)~=1)==0
                                exit_rate_firms_AboveP66(t,1) = 1000; %Large number
                            end  
                            
                        %Aggregate exit rate
                            exit_rate_firms3(t,1) = sum(age_firms(:,t)>0 & age_firms(:,t+1)<=1)/sum(age_firms(:,t)>0);
                            if sum(age_firms(:,t)>0)==0
                                exit_rate_firms3(t,1) = 1000; %Large number
                            end                     
                end
                sim.exit_rate_firms_Q1(iter_k,1) = mean(exit_rate_firms_Q1);
                sim.exit_rate_firms_Q2(iter_k,1) = mean(exit_rate_firms_Q2);
                sim.exit_rate_firms_Q3(iter_k,1) = mean(exit_rate_firms_Q3);
                sim.exit_rate_firms_Q4(iter_k,1) = mean(exit_rate_firms_Q4);
                sim.exit_rate_firms_BelowP33(iter_k,1) = mean(exit_rate_firms_BelowP33);
                sim.exit_rate_firms_AboveP66(iter_k,1) = mean(exit_rate_firms_AboveP66);
                sim.exit_rate_firms3(iter_k,1)         = mean(exit_rate_firms3);

    end
        
end

%% Constrained firms

%Extensive margin
    r.constrained = r.mu~=0;
    sim.constrainedshare_allfirms   = sum(sim.measure(r.m~=1).*r.constrained(r.m~=1))./sum(sim.measure(r.m~=1));
    for i=1:s.m_grid_size
        sim.constrainedshare_sec(i) = sum(sim.measure(r.m==i+1).*r.constrained(r.m==i+1))./sum(sim.measure(r.m==i+1));
    end
        
    %Test
        r.constrained2 = r.k_ku~=1;
        sim.constrainedshare2_allfirms = sum(sim.measure(r.m~=1).*r.constrained2(r.m~=1))./sum(sim.measure(r.m~=1));

    %Exporters
        sim.constrainedshare_X_allfirms = sum(sim.measure(r.m~=1 & r.e==1).*r.constrained(r.m~=1 & r.e==1))./sum(sim.measure(r.m~=1 & r.e==1));
        for i=1:s.m_grid_size
            sim.constrainedshare_X_sec(i) = sum(sim.measure(r.m==i+1 & r.e==1).*r.constrained(r.m==i+1 & r.e==1))./sum(sim.measure(r.m==i+1 & r.e==1));
        end
        
    %Non-exporters
        sim.constrainedshare_NX_allfirms    = sum(sim.measure(r.m~=1 & r.e==0).*r.constrained(r.m~=1 & r.e==0))./sum(sim.measure(r.m~=1 & r.e==0));
        for i=1:s.m_grid_size
            sim.constrainedshare_NX_sec(i) = sum(sim.measure(r.m==i+1 & r.e==0).*r.constrained(r.m==i+1 & r.e==0))./sum(sim.measure(r.m==i+1 & r.e==0));
        end
        
%Intensive margin, conditional on being constained
    sim.k_ku_const_allfirms = sum(sim.measure(r.m~=1 & r.constrained==1).*r.k_ku(r.m~=1 & r.constrained==1))./sum(sim.measure(r.m~=1 & r.constrained==1));
    for i=1:s.m_grid_size
        sim.k_ku_const_sec(i) = sum(sim.measure(r.m==i+1 & r.constrained==1).*r.k_ku(r.m==i+1 & r.constrained==1))./sum(sim.measure(r.m==i+1 & r.constrained==1));
    end  
    sim.k_ku_unc_allfirms = sum(sim.measure(r.m~=1 & r.constrained==0).*r.k_ku(r.m~=1 & r.constrained==0))./sum(sim.measure(r.m~=1 & r.constrained==0));        
    for i=1:s.m_grid_size
        sim.k_ku_unc_sec(i) = sum(sim.measure(r.m==i+1 & r.constrained==0).*r.k_ku(r.m==i+1 & r.constrained==0))./sum(sim.measure(r.m==i+1 & r.constrained==0));
    end  
    
    %Exporters
        sim.k_ku_const_X_allfirms   = sum(sim.measure(r.m~=1 & r.e==1 & r.constrained==1).*r.k_ku(r.m~=1 & r.e==1 & r.constrained==1))./sum(sim.measure(r.m~=1 & r.e==1 & r.constrained==1));
        for i=1:s.m_grid_size
            sim.k_ku_const_X_sec(i) = sum(sim.measure(r.m==i+1 & r.e==1 & r.constrained==1).*r.k_ku(r.m==i+1 & r.e==1 & r.constrained==1))./sum(sim.measure(r.m==i+1 & r.e==1 & r.constrained==1));
        end
        
    %Non-exporters
        sim.k_ku_const_NX_allfirms  = sum(sim.measure(r.m~=1 & r.e==0 & r.constrained==1).*r.k_ku(r.m~=1 & r.e==0 & r.constrained==1))./sum(sim.measure(r.m~=1 & r.e==0 & r.constrained==1));
        for i=1:s.m_grid_size
            sim.k_ku_const_NX_sec(i) = sum(sim.measure(r.m==i+1 & r.e==0 & r.constrained==1).*r.k_ku(r.m==i+1 & r.e==0 & r.constrained==1))./sum(sim.measure(r.m==i+1 & r.e==0 & r.constrained==1));
        end
        
%Intensive margin, unconditional
    sim.k_ku_allfirms   = sum(sim.measure(r.m~=1).*r.k_ku(r.m~=1))./sum(sim.measure(r.m~=1));
    for i=1:s.m_grid_size
        sim.k_ku_sec(i) = sum(sim.measure(r.m==i+1).*r.k_ku(r.m==i+1))./sum(sim.measure(r.m==i+1));
    end    

%Productivity
    sim.zavg_allfirms   = sum(sim.measure(r.m~=1).*r.z(r.m~=1))./sum(sim.measure(r.m~=1));
    for i=1:s.m_grid_size
        sim.zavg_sec(i) = sum(sim.measure(r.m==i+1).*r.z(r.m==i+1))./sum(sim.measure(r.m==i+1));
    end

%Net worth
    sim.aavg_allfirms   = sum(sim.measure(r.m~=1).*r.a(r.m~=1))./sum(sim.measure(r.m~=1));
    for i=1:s.m_grid_size
        sim.aavg_sec(i) = sum(sim.measure(r.m==i+1).*r.a(r.m==i+1))./sum(sim.measure(r.m==i+1));
    end

%Average exports
    sim.avgsalesf_allfirms  = sum(sim.measure(r.m~=1 & r.e==1).*r.sales_f(r.m~=1 & r.e==1))/sum(sim.measure(r.m~=1 & r.e==1));
    for i=1:s.m_grid_size
        sim.avgsalesf_sec(i) = sum(sim.measure(r.m==i+1 & r.e==1).*r.sales_f(r.m==i+1 & r.e==1))./sum(sim.measure(r.m==i+1 & r.e==1));
    end
    
%Capital
    sim.k_allfirms  = sum(sim.measure(r.m~=1).*r.k(r.m~=1));
    for i=1:s.m_grid_size
        sim.k_sec(i) = sum(sim.measure(r.m==i+1).*r.k(r.m==i+1));
    end

%Labor
    sim.n_allfirms  = sum(sim.measure(r.m~=1).*r.n(r.m~=1));
    for i=1:s.m_grid_size
        sim.n_sec(i) = sum(sim.measure(r.m==i+1).*r.n(r.m==i+1));
    end 
                           
end

