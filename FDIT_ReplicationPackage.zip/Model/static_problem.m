function sp = static_problem(m,s,r,varargin)

%Export state
    if isempty(varargin)==0     %Non-empty
        if varargin{1}==0       %Previously a non-exporter
            export_state = 0; 
        elseif varargin{1}==1   %Previously an exporter
            export_state = 1; 
        end
    elseif isempty(varargin)==1 %Empty
       export_state = 1; 
    end

%% Solution objects

%State space of the static problem
%(a,z,export,m) = Net worth x productivity x export status x occupation
%Export status in period t => 0 if firm doesn't export in period t, 1 if firm exports in period t

%4D arrays across state space
    %Net worth array = net worth value corresponding to first dimension of the array
        sp.a_grid_array = repmat(r.a_grid',[1 s.z_grid_size 2 s.m_grid_size]);
        
    %Productivity array = productivity value corresponding to second dimension of the array        
        sp.z_grid_array = repmat(r.z_grid',[s.a_grid_size 1 2 s.m_grid_size]);

    %Export status array => if third dimension =1 implies non-exporting, =2 implies firm exports    
        temp = repmat([1 2]',[1 s.a_grid_size s.z_grid_size s.m_grid_size]);
        sp.e_grid_array = permute(temp,[2 3 1 4]);
        
    %Occupation array => 1 if low-alpha firm, 2 if high-alpha firm        
        temp = repmat([1:s.m_grid_size]',[1 s.a_grid_size s.z_grid_size 2]);
        sp.m_grid_array = permute(temp,[2 3 4 1]);
    
    %Size of state space
        sp.state_space_size = size(sp.a_grid_array);
        
%Sectoral parameters        
    sp.alpha_array          = zeros(sp.state_space_size); 
    sp.phi_int_array        = zeros(sp.state_space_size); 
    sp.phi_fin_array        = zeros(sp.state_space_size); 
    sp.Px_array             = zeros(sp.state_space_size); 
    sp.theta_array          = zeros(sp.state_space_size);
    sp.delta_array          = zeros(sp.state_space_size);
    sp.sigma_array          = zeros(sp.state_space_size);
    sp.Psect_array          = zeros(sp.state_space_size);
    sp.Ysect_array          = zeros(sp.state_space_size);
    sp.A_array              = zeros(sp.state_space_size);
    sp.eta_drs_1            = zeros(sp.state_space_size);
    sp.omega_m_array        = zeros(sp.state_space_size);
    sp.omega_h_sec_array    = zeros(sp.state_space_size);    
    for i=1:s.m_grid_size         
            sp.alpha_array(:,:,:,i)         = m.alpha_vec(i);
            sp.phi_int_array(:,:,:,i)       = m.phi_int_vec(i);
            sp.phi_fin_array(:,:,:,i)       = m.phi_int_vec(i);
            sp.Px_array(:,:,:,i)            = m.Px_vec(i);
            sp.theta_array(:,:,:,i)         = m.theta_vec(i);              
            sp.delta_array(:,:,:,i)         = m.delta_vec(i);              
            sp.sigma_array(:,:,:,i)         = m.sigma_vec(i);           
            sp.Psect_array(:,:,:,i)         = m.Psect_vec(i);
            sp.Ysect_array(:,:,:,i)         = m.Ysect_vec(i);
            sp.A_array(:,:,:,i)             = m.A_vec(i); 
            sp.eta_drs_1(:,:,:,i)           = m.eta_drs_1_vec(i);
            sp.omega_m_array(:,:,:,i)       = m.omega_m_vec(i);
            sp.omega_h_sec_array(:,:,:,i)   = m.omega_h_sec_vec(i);                 
    end
    
%Export status array => 0 if non-exporter, 1 if exporter
    sp.e_array = sp.e_grid_array - 1;      
    
%% Adjust productivity to factor out intermediate inputs from the problem

for j=1:s.m_grid_size  
    
   adj_factor = m.Psect_vec(m.int_base)/m.gamma_mat(m.int_base,j);
   for k=1:s.m_grid_size+1
      adj_factor = adj_factor * ((m.gamma_mat(k,j)/m.Psect_vec(k))^(m.gamma_mat(k,j)));       
   end
   adj_factor = adj_factor.^(m.phi_int_vec(j)*m.eta_drs_2);
   
   sp.z_grid_array(:,:,:,j) = sp.z_grid_array(:,:,:,j)*adj_factor;
   
end

%% All possible export combinations

%Construct matrix of size (2^m.X_countries x m.X_countries)
%Each row indicates a different combination of export destinations
    sp.Edestinations = dec2bin(0:(2^m.X_countries)-1)=='1';

%Remove non-exporting as an option
    sp.Edestinations(1,:) = []; %Non-exporting is removed
    
%Count number of rows (possible export destination possibilities)
    sp.Edestinations_num = size(sp.Edestinations,1);    
    
%For each row, count number of export destinations    
    sp.Edestinations_countries = sum(sp.Edestinations,2);

%% Country and sector specific trade costs    

for j=1:m.X_countries
    sp.tau_array{j} = zeros(sp.state_space_size);
    sp.F_array{j}   = zeros(sp.state_space_size);
    for i=1:s.m_grid_size        
        sp.tau_array{j}(:,:,:,i) = m.X_tau(j,i); 
        sp.F_array{j}(:,:,:,i)   = m.X_Fcost(j,i); 
    end
end
    
%% Solution

for i = 1:sp.Edestinations_num

%% Case I: Unconstrained

    %Demand system
        PsiOmega = ((sp.omega_h_sec_array).^sp.sigma_array) .* (sp.Psect_array.^sp.sigma_array) .* sp.Ysect_array;
        
    %Objects used to simplify expressions
        wc_n = 1;
    
        sp.Phi0{i,1} = 1;
        for j = 1:m.X_countries
            sp.Phi0{i,1} = sp.Phi0{i} + sp.Edestinations(i,j).*sp.e_array.*(sp.tau_array{j}.^(1-sp.sigma_array)).*(m.X_Yrow(j).*(m.X_Prow(j).^sp.sigma_array))./PsiOmega;
        end                 
        
        Ups = (m.sigma-1)*m.eta_drs_2*(1+sp.phi_int_array.*sp.alpha_array-sp.alpha_array)-m.sigma;
               
        Phi1_1 = ( (m.sigma/(m.sigma-1)) .* (PsiOmega.^(-1/m.sigma)) ./ m.eta_drs_2 ) .^ (m.sigma.*m.eta_drs_2.*(1+sp.phi_int_array.*sp.alpha_array-sp.alpha_array)./Ups);
        Phi1_2 = (sp.phi_int_array./sp.Px_array).^(-sp.phi_int_array.*m.sigma.*m.eta_drs_2./Ups);
        Phi1_3 = (m.w*wc_n./( (1-sp.alpha_array) .* (1-sp.phi_int_array) )).^(m.sigma*m.eta_drs_2*(1-sp.alpha_array).*(1-sp.phi_int_array)./Ups);
        Phi1_4 = sp.Phi0{i}.^( m.sigma.* ( (1-(1-sp.alpha_array).*(1-sp.phi_int_array).*m.eta_drs_2).*(1+sp.phi_int_array.*sp.alpha_array-sp.alpha_array) - sp.phi_int_array )...
                    ./ ( (1-sp.alpha_array).*(1-sp.phi_int_array).*Ups ) );
        sp.Phi1{i,1} = Phi1_1.*Phi1_2.*Phi1_3.*Phi1_4;       
       
        %Phi2
        Phi2_1 = (sp.alpha_array./( m.P*(m.r+m.delta)*(1-sp.alpha_array) )).^(-m.eta_drs_2*(1+sp.phi_int_array.*sp.alpha_array-sp.alpha_array));
        Phi2_2 = (sp.phi_int_array./(sp.Px_array.*(1-sp.alpha_array).*(1-sp.phi_int_array))).^(sp.phi_int_array*m.eta_drs_2);
        Phi2_3 = (m.w*wc_n).^(-(1-sp.alpha_array).*(1-sp.phi_int_array)*m.eta_drs_2);
        Phi2_4 = sp.Phi0{i}.^(-1);
        sp.Phi2{i,1} = Phi2_1.*Phi2_2.*Phi2_3.*Phi2_4;

    %Capital
        Xi_1 = sp.eta_drs_1;
        Xi_2 = -sp.eta_drs_1*m.sigma./Ups;
        
        Ups_1 = m.eta_drs_2;
        Ups_2 = -sp.alpha_array.*m.sigma.*(1-sp.phi_int_array).*m.eta_drs_2./Ups;

        sp.k_u{i,1} = ((sp.Phi1{i}./sp.Phi2{i}).^(1./(Ups_1-Ups_2))) .* ( (sp.A_array.*m.B).^((Xi_2-Xi_1)./(Ups_1-Ups_2)) ) .* sp.z_grid_array.^(-(Ups+m.sigma)./(Ups.*(Ups_1-Ups_2)));
    
    %Domestic sales        
        yh_u_1 = sp.Phi1{i};
        yh_u_2 = (sp.A_array.*m.B).^(-sp.eta_drs_1.*m.sigma./Ups);
        yh_u_3 = sp.z_grid_array.^(-m.sigma./Ups);
        yh_u_4 = sp.k_u{i}.^(-sp.alpha_array.*m.sigma.*(1-sp.phi_int_array).*m.eta_drs_2./Ups);
        sp.yh_u{i,1} = yh_u_1.*yh_u_2.*yh_u_3.*yh_u_4;
        
    %Rest of the variables
        %Exports
            for j = 1:m.X_countries
                sp.yf_u{i,j} = sp.Edestinations(i,j)*(sp.tau_array{j}.^(-sp.sigma_array)).*sp.yh_u{i}.*(m.X_Yrow(j).*(m.X_Prow(j).^sp.sigma_array))./PsiOmega; 
                sp.yf_u{i,j}(:,:,1,:) = 0; %Non-exporting

                if sp.Edestinations(i,j)~=0
                    sp.pf_u{i,j} = ((sp.yf_u{i,j}/m.X_Yrow(j)).^(-1./sp.sigma_array))*m.X_Prow(j);
                    sp.pf_u{i,j}(:,:,1,:) = 0;   
                elseif sp.Edestinations(i,j)==0
                    sp.pf_u{i,j} = zeros(size(sp.yf_u{i,j}));
                end       
            end

            sp.yf_u_total_withtau{i,1} = 0;
            for j = 1:m.X_countries
                sp.yf_u_total_withtau{i,1} = sp.yf_u_total_withtau{i} + sp.tau_array{j}.*sp.yf_u{i,j};
            end    
                    
        %Intermediate inputs
            x_u_1 = ((m.w./sp.Px_array).*wc_n.*sp.phi_int_array./((1-sp.alpha_array).*(1-sp.phi_int_array)))...
                    .^( (1-sp.alpha_array).*(1-sp.phi_int_array)./(1+sp.phi_int_array.*sp.alpha_array-sp.alpha_array) );
            x_u_2 = (sp.yh_u{i}.*sp.Phi0{i}).^(1./((m.eta_drs_2).*(1+sp.phi_int_array.*sp.alpha_array-sp.alpha_array)));
            x_u_3 = (sp.A_array.*m.B).^(-sp.eta_drs_1./((m.eta_drs_2).*(1+sp.phi_int_array.*sp.alpha_array-sp.alpha_array)));
            x_u_4 = sp.z_grid_array.^(-1./(m.eta_drs_2.*(1+sp.phi_int_array.*sp.alpha_array-sp.alpha_array)));
            x_u_5 = sp.k_u{i}.^(-sp.alpha_array.*(1-sp.phi_int_array)./(1+sp.phi_int_array.*sp.alpha_array-sp.alpha_array));
            
            sp.x_u{i} = x_u_1.*x_u_2.*x_u_3.*x_u_4.*x_u_5;

        %Labor
            n_u_1 = (sp.yh_u{i}+sp.yf_u_total_withtau{i}) ./ ( sp.z_grid_array.*((sp.A_array.*m.B).^sp.eta_drs_1)...
                    .* ((sp.k_u{i}.^(sp.alpha_array.*(1-sp.phi_int_array))) .* (sp.x_u{i}.^sp.phi_int_array)).^(m.eta_drs_2) );
            sp.n_u{i,1} = n_u_1.^(1./((1-sp.alpha_array).*(1-sp.phi_int_array).*(m.eta_drs_2)));

        %Domestic price
            sp.ph_u{i,1} = (sp.yh_u{i}./PsiOmega).^(-1./sp.sigma_array);
      
        %Lagrange multiplier
            sp.mu_u{i,1} = zeros(sp.state_space_size);                  
        
%% Which firms are constrained?
 
const_temp = m.P*sp.k_u{i}.*((1+m.r-sp.theta_array)./(1+m.r));
for ia=1:s.a_grid_size
    for iz=1:s.z_grid_size
        for ie=1:2
            for im=1:s.m_grid_size
                const_temp(ia,iz,ie,im) = const_temp(ia,iz,ie,im) + (1-export_state)*(ie-1)*m.eta_S*m.w*m.Scost + m.eta_F*m.w*m.F_vec(im)*(ie-1) + m.eta_M*m.w*m.M1_vec(im);                        
            end
        end
    end
end
sp.constrained_etaN0{i,1} = const_temp > m.P*sp.a_grid_array;
sp.constrained_num_etaN0{i,1} = sum(sp.constrained_etaN0{i}(:));    
            
%% Case II: Constrained 
  
sp.infeasible = zeros(sp.state_space_size);

if sp.constrained_num_etaN0{i}>0
    
    %Capital      
        k_temp = m.P*sp.a_grid_array;
        for ia=1:s.a_grid_size
            for iz=1:s.z_grid_size
                for ie=1:2
                    for im=1:s.m_grid_size
                        k_temp(ia,iz,ie,im) = k_temp(ia,iz,ie,im) - (1-export_state)*(ie-1)*m.eta_S*m.w*m.Scost - m.eta_F*m.w*m.F_vec(im)*(ie-1) - m.eta_M*m.w*m.M1_vec(im);                             
                        k_temp(ia,iz,ie,im) = k_temp(ia,iz,ie,im).*((1+m.r)./(1+m.r-sp.theta_array(ia,iz,ie,im))).*(1/m.P);
                        if k_temp(ia,iz,ie,im)<=0
                            sp.infeasible(ia,iz,ie,im) = 1;
                            k_temp(ia,iz,ie,im) = 0; %1e-8;
                        end
                    end
                end
            end
        end
        sp.k_c_etaN0{i} = k_temp(sp.constrained_etaN0{i});                  

    %Domestic sales
        yh_c_1 = sp.Phi1{i}(sp.constrained_etaN0{i});
        yh_c_2 = (m.B*sp.A_array(sp.constrained_etaN0{i})).^(-sp.eta_drs_1(sp.constrained_etaN0{i}).*m.sigma./Ups(sp.constrained_etaN0{i}));
        yh_c_3 = sp.z_grid_array(sp.constrained_etaN0{i}).^(-m.sigma./Ups(sp.constrained_etaN0{i}));
        yh_c_4 = sp.k_c_etaN0{i}.^(-sp.alpha_array(sp.constrained_etaN0{i}).*m.sigma.*(1-sp.phi_int_array(sp.constrained_etaN0{i})).*(m.eta_drs_2)./Ups(sp.constrained_etaN0{i}));
        sp.yh_c_etaN0{i,1} = yh_c_1.*yh_c_2.*yh_c_3.*yh_c_4;            

    %Intermediates
        x_c_1 = ((m.w./sp.Px_array(sp.constrained_etaN0{i})).*wc_n.*sp.phi_int_array(sp.constrained_etaN0{i})...
                ./((1-sp.alpha_array(sp.constrained_etaN0{i})).*(1-sp.phi_int_array(sp.constrained_etaN0{i}))))...
                .^( (1-sp.alpha_array(sp.constrained_etaN0{i})).*(1-sp.phi_int_array(sp.constrained_etaN0{i}))...
                ./(1+sp.phi_int_array(sp.constrained_etaN0{i}).*sp.alpha_array(sp.constrained_etaN0{i})-sp.alpha_array(sp.constrained_etaN0{i})) );
        x_c_2 = (sp.yh_c_etaN0{i}.*sp.Phi0{i}(sp.constrained_etaN0{i}))...
                .^(1./((m.eta_drs_2)*(1+sp.phi_int_array(sp.constrained_etaN0{i}).*sp.alpha_array(sp.constrained_etaN0{i})-sp.alpha_array(sp.constrained_etaN0{i}))));
        x_c_3 = (m.B*sp.A_array(sp.constrained_etaN0{i})).^(-sp.eta_drs_1(sp.constrained_etaN0{i})...
                ./((m.eta_drs_2)*(1+sp.phi_int_array(sp.constrained_etaN0{i}).*sp.alpha_array(sp.constrained_etaN0{i})-sp.alpha_array(sp.constrained_etaN0{i}))));
        x_c_4 = sp.z_grid_array(sp.constrained_etaN0{i})...
                .^(-1./(m.eta_drs_2.*(1+sp.phi_int_array(sp.constrained_etaN0{i}).*sp.alpha_array(sp.constrained_etaN0{i})-sp.alpha_array(sp.constrained_etaN0{i}))));
        x_c_5 = sp.k_c_etaN0{i}.^(-sp.alpha_array(sp.constrained_etaN0{i}).*(1-sp.phi_int_array(sp.constrained_etaN0{i}))...
                ./(1+sp.phi_int_array(sp.constrained_etaN0{i}).*sp.alpha_array(sp.constrained_etaN0{i})-sp.alpha_array(sp.constrained_etaN0{i})));

        sp.x_c_etaN0{i} = x_c_1.*x_c_2.*x_c_3.*x_c_4.*x_c_5;
               
    %Lagrange multiplier
        mu_c_etaN0_1 = (sp.alpha_array(sp.constrained_etaN0{i})./(1-sp.alpha_array(sp.constrained_etaN0{i})))*m.w*wc_n;
        mu_c_etaN0_2 = (sp.yh_c_etaN0{i}.*sp.Phi0{i}(sp.constrained_etaN0{i})).^(1./((1-sp.alpha_array(sp.constrained_etaN0{i})).*(1-sp.phi_int_array(sp.constrained_etaN0{i})).*m.eta_drs_2));
        mu_c_etaN0_3 = (m.B*sp.A_array(sp.constrained_etaN0{i}))...
                        .^(-sp.eta_drs_1(sp.constrained_etaN0{i})./((1-sp.alpha_array(sp.constrained_etaN0{i})).*(1-sp.phi_int_array(sp.constrained_etaN0{i})).*m.eta_drs_2));
        mu_c_etaN0_4 = (sp.z_grid_array(sp.constrained_etaN0{i}))...
                        .^(-1./((1-sp.alpha_array(sp.constrained_etaN0{i})).*(1-sp.phi_int_array(sp.constrained_etaN0{i})).*m.eta_drs_2));
        mu_c_etaN0_5 = sp.x_c_etaN0{i}.^(-sp.phi_int_array(sp.constrained_etaN0{i})./((1-sp.alpha_array(sp.constrained_etaN0{i})).*(1-sp.phi_int_array(sp.constrained_etaN0{i}))));
        mu_c_etaN0_6 = sp.k_c_etaN0{i}.^(-1./(1-sp.alpha_array(sp.constrained_etaN0{i}))); 
    
        sp.mu_c_etaN0{i,1} = (mu_c_etaN0_1.*mu_c_etaN0_2.*mu_c_etaN0_3.*mu_c_etaN0_4.*mu_c_etaN0_5.*mu_c_etaN0_6 - m.P.*(m.r+m.delta)) .* (1+m.r)...
                            ./(m.P.*(1+m.r-sp.theta_array(sp.constrained_etaN0{i})));                    
        sp.mu_c_etaN0{i}(not(sp.mu_c_etaN0{i}>0)) = 0;  
end

%% Optimal choices of k and yh
      
%Unconstrained
    sp.k{i,1}       = sp.k_u{i};
    sp.k_ku{i,1}    = ones(size(sp.k_u{i}));        
    sp.yh{i,1}      = sp.yh_u{i};
    sp.x{i,1}       = sp.x_u{i};
    sp.mu{i,1}      = sp.mu_u{i};
    
%Constrained    
    if sp.constrained_num_etaN0{i}>0
        sp.k{i}(sp.constrained_etaN0{i})    = sp.k_c_etaN0{i};
        sp.k_ku{i}(sp.constrained_etaN0{i}) = sp.k{i}(sp.constrained_etaN0{i})./sp.k_u{i}(sp.constrained_etaN0{i});   
        sp.yh{i}(sp.constrained_etaN0{i})   = sp.yh_c_etaN0{i};
        sp.x{i}(sp.constrained_etaN0{i})    = sp.x_c_etaN0{i};
        sp.mu{i}(sp.constrained_etaN0{i})   = sp.mu_c_etaN0{i};
    end

%% Rest of the variables

%Intermediates
    sp.h{i} = zeros([sp.state_space_size s.m_grid_size+1]);
    for j = 1:s.m_grid_size                          
        for k = 1:s.m_grid_size+1
            sp.h{i}(:,:,:,j,k) = m.gamma_mat(k,j)*(m.Psect_vec(m.int_base)*sp.x{i}(:,:,:,j)/m.gamma_mat(m.int_base,j))/m.Psect_vec(k);            
        end
    end 

%Exports
    for j = 1:m.X_countries
        sp.yf{i,j} = sp.Edestinations(i,j)*(sp.tau_array{j}.^(-sp.sigma_array)).*sp.yh{i}.*(m.X_Yrow(j).*(m.X_Prow(j).^sp.sigma_array))./PsiOmega; 
        sp.yf{i,j}(:,:,1,:) = 0; %Non-exporter

        if sp.Edestinations(i,j)~=0
            sp.pf{i,j} = ((sp.yf{i,j}/m.X_Yrow(j)).^(-1./sp.sigma_array))*m.X_Prow(j);
            sp.pf{i,j}(:,:,1,:) = 0; %Non-exporter
        elseif sp.Edestinations(i,j)==0
            sp.pf{i,j} = zeros(size(sp.yf{i,j}));
        end   
        sp.pf{i,j}(sp.yf{i}==0) = 0;   
    end
    
    sp.yf_total_withtau{i,1} = 0;
    for j = 1:m.X_countries
        sp.yf_total_withtau{i,1} = sp.yf_total_withtau{i} + sp.tau_array{j}.*sp.yf{i,j};
    end    

%Labor
    n_1 = (sp.yh{i}+sp.yf_total_withtau{i}) ./ ( sp.z_grid_array.*((m.B*sp.A_array).^sp.eta_drs_1)...
            .* ((sp.k{i}.^(sp.alpha_array.*(1-sp.phi_int_array))) .* (sp.x{i}.^sp.phi_int_array)).^(m.eta_drs_2) );
    sp.n{i,1} = n_1.^(1./((1-sp.alpha_array).*(1-sp.phi_int_array).*(m.eta_drs_2)));
    
%Domestic price    
    sp.ph{i,1} = (sp.yh{i}./PsiOmega).^(-1./sp.sigma_array);
    sp.ph{i}(sp.yh{i}==0) = 0;          
        
%Profits
    sp.pfyf_total{i,1} = 0;
    for j = 1:m.X_countries
        sp.pfyf_total{i,1} = sp.pfyf_total{i} + sp.pf{i,j}.*sp.yf{i,j};            
    end     
    
    sp.X_Fcost_total{i,1} = 0;
    for j = 1:m.X_countries
        sp.X_Fcost_total{i,1} = sp.X_Fcost_total{i,1} + sp.Edestinations(i,j)*sp.F_array{j};
    end
    sp.X_Fcost_total{i,1}(:,:,1,:) = 0;
    
    sp.pi{i,1} = sp.ph{i}.*sp.yh{i} + sp.pfyf_total{i} - m.P.*sp.k{i}.*(m.r+sp.delta_array) - m.w.*sp.n{i} - sp.Px_array.*sp.x{i};
    sp.pi{i}(:,:,2,:) = sp.pi{i}(:,:,2,:) - m.w*((1-m.eta_F)+(1+m.r)*m.eta_F)*sp.X_Fcost_total{i}(:,:,2,:);
    for j=1:s.m_grid_size
        sp.pi{i}(:,:,:,j) = sp.pi{i}(:,:,:,j) - m.w*((1-m.eta_M)+(1+m.r)*m.eta_M)*m.M1_vec(j);    
    end       
    
    %Assign very low profits to infeasible options
        sp.pi{i}(sp.infeasible==1) = -1e8;
    
end

%% Clear stuff

if s.clearmemory==1
    sp = rmfield(sp,{'a_grid_array','z_grid_array','e_grid_array','m_grid_array','alpha_array','theta_array','delta_array','sigma_array','Psect_array','e_array',...
         'A_array','Phi0','Phi1','Phi2','k_u','yh_u','mu_u'});
end
   
%% Choose optimal set of destinations

sp.Edestinations_optimal = ones(sp.state_space_size);
sp.pi_max = sp.pi{1};
if sp.Edestinations_num>1
    for i=2:sp.Edestinations_num
        ind = sp.pi_max>=sp.pi{i};
        sp.Edestinations_optimal    = ind.*sp.Edestinations_optimal + (1-ind).*i;
        sp.pi_max                   = ind.*sp.pi_max                + (1-ind).*sp.pi{i};        
    end
end

%% Set optimal policies given optimal set of destinations

k_ku_temp           = zeros(s.a_grid_size,s.z_grid_size,s.x_grid_size,s.m_grid_size);
mu_temp             = zeros(s.a_grid_size,s.z_grid_size,s.x_grid_size,s.m_grid_size);
ph_temp             = zeros(s.a_grid_size,s.z_grid_size,s.x_grid_size,s.m_grid_size);
yh_temp             = zeros(s.a_grid_size,s.z_grid_size,s.x_grid_size,s.m_grid_size);
pf_temp             = zeros(s.a_grid_size,s.z_grid_size,s.x_grid_size,s.m_grid_size,m.X_countries);
yf_temp             = zeros(s.a_grid_size,s.z_grid_size,s.x_grid_size,s.m_grid_size,m.X_countries);
n_temp              = zeros(s.a_grid_size,s.z_grid_size,s.x_grid_size,s.m_grid_size);
x_temp              = zeros(s.a_grid_size,s.z_grid_size,s.x_grid_size,s.m_grid_size);
k_temp              = zeros(s.a_grid_size,s.z_grid_size,s.x_grid_size,s.m_grid_size);
pi_temp             = zeros(s.a_grid_size,s.z_grid_size,s.x_grid_size,s.m_grid_size);
pfyf_total_temp     = zeros(s.a_grid_size,s.z_grid_size,s.x_grid_size,s.m_grid_size);
X_Fcost_total_temp  = zeros(s.a_grid_size,s.z_grid_size,s.x_grid_size,s.m_grid_size);
h_temp              = zeros(s.a_grid_size,s.z_grid_size,s.x_grid_size,s.m_grid_size,s.m_grid_size+1);

for i = 1:sp.Edestinations_num
    
    Edestinations_optimal_temp = sp.Edestinations_optimal==i;
    
    k_ku_temp(Edestinations_optimal_temp) = sp.k_ku{i}(Edestinations_optimal_temp);   
    
    mu_temp(Edestinations_optimal_temp)            = sp.mu{i}(Edestinations_optimal_temp);

    ph_temp(Edestinations_optimal_temp)            = sp.ph{i}(Edestinations_optimal_temp);
    yh_temp(Edestinations_optimal_temp)            = sp.yh{i}(Edestinations_optimal_temp);                

    n_temp(Edestinations_optimal_temp)             = sp.n{i}(Edestinations_optimal_temp);
    x_temp(Edestinations_optimal_temp)             = sp.x{i}(Edestinations_optimal_temp);
    k_temp(Edestinations_optimal_temp)             = sp.k{i}(Edestinations_optimal_temp);                
    pi_temp(Edestinations_optimal_temp)            = sp.pi{i}(Edestinations_optimal_temp);  

    pfyf_total_temp(Edestinations_optimal_temp)    = sp.pfyf_total{i}(Edestinations_optimal_temp);  

    X_Fcost_total_temp(Edestinations_optimal_temp) = sp.X_Fcost_total{i}(Edestinations_optimal_temp); 

    for l = 1:s.m_grid_size+1
        Edestinations_optimal_temp2 = false(s.a_grid_size,s.z_grid_size,s.x_grid_size,s.m_grid_size,s.m_grid_size+1);
        Edestinations_optimal_temp2(:,:,:,:,l) = Edestinations_optimal_temp;
        h_temp(Edestinations_optimal_temp2)    = sp.h{i}(Edestinations_optimal_temp2);
    end        
    
end

%Exports
    if m.X_countries==1        
        for i = 1:sp.Edestinations_num
            Edestinations_optimal_temp = sp.Edestinations_optimal==i;
            pf_temp(Edestinations_optimal_temp) = sp.pf{i}(Edestinations_optimal_temp);
            yf_temp(Edestinations_optimal_temp) = sp.yf{i}(Edestinations_optimal_temp);  
        end                    
    else        
        for i = 1:s.a_grid_size
            for j = 1:s.z_grid_size   
                for k = 1:s.x_grid_size 
                    for t = 1:s.m_grid_size
                        for u = 1:m.X_countries
                            Edestinations_optimal_temp = sp.Edestinations_optimal(i,j,k,t)==u;
                            pf_temp(Edestinations_optimal_temp,u) = sp.pf{Edestinations_optimal_temp,u}(i,j,k,t);
                            yf_temp(Edestinations_optimal_temp,u) = sp.yf{Edestinations_optimal_temp,u}(i,j,k,t);
                        end
                    end
                end
            end
        end        
    end
  
%Store    
    sp.k_ku             = k_ku_temp;
    sp.mu               = mu_temp;
    sp.ph               = ph_temp;
    sp.yh               = yh_temp;
    sp.pf               = pf_temp;
    sp.yf               = yf_temp;
    sp.n                = n_temp;
    sp.x                = x_temp;
    sp.k                = k_temp;
    sp.pi               = pi_temp;
    sp.pfyf_total       = pfyf_total_temp;
    sp.X_Fcost_total    = X_Fcost_total_temp;
    sp.h                = h_temp;
    
end