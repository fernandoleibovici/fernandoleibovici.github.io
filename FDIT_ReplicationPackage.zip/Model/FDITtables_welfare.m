function x = FDITtables_welfare(wksp)

%% Workspace

%Baseline
    m = wksp{1}.m;
    sim = wksp{1}.sim;

    m_L = wksp{1}.exp_m{1};
    sim_L = wksp{1}.exp_sim{1};

    m_H = wksp{1}.exp_m{2};
    sim_H = wksp{1}.exp_sim{2};

%International financial autarky    
    m_IFA = wksp{2}.m;
    sim_IFA = wksp{2}.sim;

    m_L_IFA = wksp{2}.exp_m{1};
    sim_L_IFA = wksp{2}.exp_sim{1};

    m_H_IFA = wksp{2}.exp_m{2};
    sim_H_IFA = wksp{2}.exp_sim{2};
    
%International financial autarky + Closed to trade
    m_IFAClosed = wksp{3}.m;
    sim_IFAClosed = wksp{3}.sim;

    m_L_IFAClosed = wksp{3}.exp_m{1};
    sim_L_IFAClosed = wksp{3}.exp_sim{1};

    m_H_IFAClosed = wksp{3}.exp_m{2};
    sim_H_IFAClosed = wksp{3}.exp_sim{2};    
    
%% Table 4: Gains from financial development

fprintf('\n');
disp('=========================================');
disp('Table 4: Gains from financial development');  
disp('=========================================');
fprintf('                    Baseline     Financial autarky     Closed economy     Role of trade\n');
fprintf('-----------------------------------------------------------------------------------------------------\n');
fprintf('Welfare         %8.2f%%    %8.2f%%             %8.2f%%          %8.2f%%  \n',[(exp((1-m.beta)*(sim_H.welfare-sim_L.welfare))-1) ...
        (exp((1-m.beta)*(sim_H_IFA.welfare-sim_L_IFA.welfare))-1) (exp((1-m.beta)*(sim_H_IFAClosed.welfare-sim_L_IFAClosed.welfare))-1) ...
        (exp((1-m.beta)*(sim_H_IFA.welfare-sim_L_IFA.welfare))-1)-(exp((1-m.beta)*(sim_H_IFAClosed.welfare-sim_L_IFAClosed.welfare))-1)]*100); 
fprintf('Consumption     %8.2f%%    %8.2f%%             %8.2f%%          %8.2f%%  \n',...
    [log(sim_H.C/sim_L.C)*100 log(sim_H_IFA.C/sim_L_IFA.C)*100 log(sim_H_IFAClosed.C/sim_L_IFAClosed.C)*100 (log(sim_H_IFA.C/sim_L_IFA.C)-log(sim_H_IFAClosed.C/sim_L_IFAClosed.C))*100]);
fprintf('Absorption      %8.2f%%    %8.2f%%             %8.2f%%          %8.2f%%  \n',...
    [log(sim_H.Y/sim_L.Y)*100 log(sim_H_IFA.Y/sim_L_IFA.Y)*100 log(sim_H_IFAClosed.Y/sim_L_IFAClosed.Y)*100 (log(sim_H_IFA.Y/sim_L_IFA.Y)-log(sim_H_IFAClosed.Y/sim_L_IFAClosed.Y))*100]);
fprintf('=====================================================================================================\n');

%% End

end
