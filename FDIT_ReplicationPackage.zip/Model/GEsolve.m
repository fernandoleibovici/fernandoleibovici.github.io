function [mcc,sim,r,s,m,sp_nx,sp_x] = GEsolve(x,m,s,r)       

%% GE vector

%Remove imaginary values
    x = real(x);
    
%Guessed values are in logs   
%Here we compute exp(x) to obtain levels of the guessed values
    x = exp(x);

%Economy without international trade    
%Do not guess wage; set it to equal 1
    if s.notrade==1
        temp = [1 x];
        x = temp;
    end

%% Aggregate prices and quantities

x(isinf(x)) = 999999;

%Guessed prices and quantities
    %Wages
        m.w = max(x(1),1e-8);   

    %Sectoral prices
        m.Psect_vec = max(x(2:2+s.m_grid_size-1),1e-8); 

    %Sectoral quantities
        m.Ysect_vec = max(x(2+s.m_grid_size:2+2*s.m_grid_size-1),1e-8);                

    %Interest rate
       if s.ifi==0 && m.theta~=0
           m.r = 0.3 * max(x(end),0.0001)/(1+max(x(end),0.0001)) - (m.delta - 1e-6);
       end        
       if s.ifi==0 && m.theta==0
          m.r = -m.delta; 
       end           

%Price of non-tradable goods
%Solve given wage and price of tradable sectoral goods
    NTprice_z = (1/m.z_NT);

    NTprice_wage = (m.w/(1-m.phi_int_vec(s.m_grid_size+1)))^(1-m.phi_int_vec(s.m_grid_size+1));

    NTprice_int = 1;
    for k=1:s.m_grid_size
        NTprice_int = NTprice_int * ((m.Psect_vec(k)/(m.phi_int_vec(s.m_grid_size+1)*m.gamma_mat(k,s.m_grid_size+1))).^m.gamma_mat(k,s.m_grid_size+1));
    end
    NTprice_int = NTprice_int.^m.phi_int_vec(s.m_grid_size+1);
    
    Ntprice_const = (1/(m.phi_int_vec(s.m_grid_size+1)*m.gamma_mat(s.m_grid_size+1,s.m_grid_size+1)))...
                    ^(m.phi_int_vec(s.m_grid_size+1)*m.gamma_mat(s.m_grid_size+1,s.m_grid_size+1));
        
    m.P_NT = (Ntprice_const .* NTprice_z .* NTprice_wage .* NTprice_int).^(1/(1-m.phi_int_vec(s.m_grid_size+1)*m.gamma_mat(s.m_grid_size+1,s.m_grid_size+1)));   
    m.P_NT = (1+m.r*(1-m.theta_wc))*m.P_NT;
    m.Psect_vec(s.m_grid_size+1) = m.P_NT;
    
%Final good price
    m.P = 1;
    for i=1:s.m_grid_size+1
       m.P = m.P * ((m.Psect_vec(i)/m.phi_fin_vec(i))^m.phi_fin_vec(i)); 
    end     
    m.P = m.P^(1/sum(m.phi_fin_vec));  
        
%Price of intermediate inputs
    m.Px_vec = m.Psect_vec(m.int_base)./m.gamma_mat(m.int_base,:);
    
%Profits
    m.Pi = 0;

%Lump-sum taxes    
    if m.nu>0
        m.a_new = 1;
        r.T = m.P*(m.nu_z_grid'*r.z_pi)*r.a_grid(m.a_new);     
    else
        r.T = 0;
    end    
    
%% Solve

%Static problem
%sp_nx  => Static problem in period t conditional on not exporting in period t-1
%sp_x   => Static problem in period t conditional on     exporting in period t-1
    if m.eta_S==0       %No working capital constraint on sunk export entry cost
        sp_nx   = static_problem(m,s,r);
        sp_x    = sp_nx;
    elseif m.eta_S~=0   %Working capital constraint on sunk export entry cost
        sp_nx   = static_problem(m,s,r,0); 
        sp_x    = static_problem(m,s,r,1);
    end

%Dynamic problem
    r = dynamic_problem(m,s,r,sp_nx,sp_x);  

%Simulate
    [sim,r,s] = model_simulate(m,s,r); 
        
%% Market clearing conditions

%Labor    
    sim.n_supply    = sim.Ns; 
    sim.n_demand    = sim.N_T + sim.N_NT;    
    sim.mc_n        = log(sim.n_supply/sim.n_demand);   
    
    %Boundaries
        if sim.n_supply<=0 
            sim.mc_n = 1e8/m.w; %Wage is too low    => Want higher wage
        end   
        if sim.n_demand<=0 
            sim.mc_n = 1e8*m.w; %Wage is to high    => Want lower wage
        end        
        if isnan(sim.mc_n)==1 || isinf(sim.mc_n)==1
           sim.mc_n = 1e8; 
        end
    
%Assets 
%This market clearing condition is the result of reformulating the debt market clearing condition
%In the original model, the sum of debt has to equal zero. Once the model is reformulated, this condition becomes the one below.  
    sim.a_supply    = sim.A;
    sim.a_demand    = sim.K + (m.w/m.P)*m.eta_S*sum(sum(squeeze(sim.measure(1,:,:).*r.e(1,:,:)).*m.S_mat)) +...
                      (m.w/m.P)*m.eta_F*sum(sum(sum(sim.measure.*r.e.*r.X_Fcost_total))) + (m.w/m.P)*m.eta_M*sim.E_fc;
    sim.mc_a        = log(sim.a_demand/sim.a_supply);  

    if sim.a_supply<=0
        sim.mc_a = 1e8/(1+100*m.r); %Interest rate is too low => Want higher interest rate
    end
    if sim.a_demand<=0
        sim.mc_a = 1e8*(1+100*m.r); %Interest rate is too high => Want lower interest rate
    end
    if isnan(sim.mc_a)==1 || isinf(sim.mc_a)==1
        sim.mc_a = 1e8; 
    end
    
%Final goods     
%Total production of final goods is used for: (i) consumption, (ii) investment
%Consumption expenditures are straightforward to compute
%Aggregate investment is derived as follows: integral[k' - (1-delta)k] 
%Now, integral[(1-delta)k]=(1-delta)kagg and integral(k')=kagg
%Then, aggregate investment equals delta*kagg
    sim.y_supply     = sim.Y; 
    sim.y_demand     = sim.C + m.delta*sim.K + max(0,m.w*sim.N_NT/sim.P)*(m.r*(1-m.theta_wc)) + max(0,sim.h_NT_value/sim.P*(m.r*(1-m.theta_wc)));               
    sim.mc_y         = log(sim.y_demand/sim.y_supply);       
    
    %Boundaries
        if sim.y_supply<=0 
            sim.mc_y = 1e8/m.P; %Price is too low     => Want higher price
        end
        if sim.y_demand<=0 
            sim.mc_y = 1e8*m.P; %Price is too high    => Want lower price
        end    
        if isnan(sim.mc_y)==1 || isinf(sim.mc_y)==1
           sim.mc_y = 1e8; 
        end

%Sectoral goods used to produce final goods
    sim.mc_Ysect_fin = log(sim.Ysect_fin_vec./sim.Ysect_final_demand);
    sim.mc_Ysect_int = log(sim.intermediates(k)./sim.Ysect_int_demand);
    
%Sectoral goods
%This condition effectively checks whether sectoral goods used to produce final goods clear
    sim.mc_Ysect = log(sim.Ysect_vec./sim.Ysect_demand);  
    
%Beliefs
    sim.mc_p_belief         = log(sim.P/m.P);   
    sim.mc_Ysect_belief_vec = log(sim.Ysect_vec(1:s.m_grid_size)./m.Ysect_vec(1:s.m_grid_size)); 
    sim.mc_Psect_belief_vec = log(sim.Psect_vec./m.Psect_vec);

    %Boundaries
        if sim.P==0
            sim.mc_p_belief = 1e8/m.P; %Want higher price
        end   
        if isnan(sim.P)==1 || isinf(sim.P)==1
           sim.mc_p_belief = 1e8; 
        end
                
        if sim.Y==0
            sim.mc_y_belief = -1e8*m.P; %Want lower price
        end   
        if isnan(sim.Y)==1 || isinf(sim.Y)==1
           sim.mc_y_belief = 1e8; 
        end        
                
        for i=1:s.m_grid_size+1
            if sim.Psect_vec(i)==0
                sim.mc_Psect_belief_vec(i) = 1e8; %Want higher price
            end  
            if isnan(sim.Psect_vec(i))==1 || isinf(sim.Psect_vec(i))==1
               sim.mc_Psect_belief_vec(i) = 1e8; 
            end                                      
        end  
         
%Vectorized   
%Do not need to check labor market clearing condition since labor in NT sector is chosen to satisfy this condition
    mcc = [sim.mc_Ysect sim.mc_Ysect_belief_vec sim.mc_Psect_belief_vec]; 
    if s.ifi==0 && m.theta~=0
       mcc(end+1)           = sim.mc_a; 
    end
    mcc                     = 1000*mcc; %Rescale to improve GE convergence
    mcc(isfinite(mcc)==0)   = 1e8;
    mcc(isreal(mcc)==0)     = 1e8;
    mcc(isnan(mcc)==1)      = 1e8;
        
    %Store
        sim.mcc_avg_pct     = mean(abs(mcc)); %Express as a percentage    
        sim.mcc             = mcc; 

    %Alternative objective
        if s.GE==2
            mcc = nansum((abs(mcc)));
        end
        
%% Display

if s.display==1  
    
    fprintf('\n');
    disp('---------------------------------------------------------------');  
    fprintf('(1) SMM \n');        
    disp(  ['GE vector  = ' num2str(x,'%12.6f ')]);    
    fprintf('\n');

    fprintf('(2) Prices \n');
    fprintf('w               = %12.6f \n',m.w);        
    fprintf('r               = %12.6f \n',m.r);    
    fprintf('Yrow            = %12.6f \n',m.Yrow);    
    fprintf('\n');
    
    fprintf('(3)               Supply            Demand         Difference \n');
    fprintf('Y            %12.6f      %12.6f      %+12.6e \n',sim.y_supply,sim.y_demand,sim.mc_y);
    for i=1:s.m_grid_size+1
        fprintf('Y%d mcc       %12.6f      %12.6f      %+12.6e \n',i,sim.Ysect_vec(i),sim.Ysect_demand(i),sim.mc_Ysect(i));
    end               
    fprintf('A            %12.6f      %12.6f      %+12.6e \n',sim.a_supply,sim.a_demand,sim.mc_a);
    fprintf('Add - N      %12.6f      %12.6f      %+12.6e \n',sim.n_supply,sim.n_demand,sim.mc_n);    
    for i=1:s.m_grid_size+1
        fprintf('Add-Y%d_FG mcc%12.6f      %12.6f      %+12.6e \n',i,sim.Ysect_fin_vec(i),sim.Ysect_final_demand(i),sim.mc_Ysect_fin(i));
    end      
    fprintf('\n');

    fprintf('(4)               Belief           Realized        Difference \n');
    for i=1:s.m_grid_size
    fprintf('Y%d belief    %12.6f      %12.6f      %+12.6e \n',i,m.Ysect_vec(i),sim.Ysect_vec(i),sim.mc_Ysect_belief_vec(i));
    end   
    for i=1:s.m_grid_size+1
    fprintf('P%d belief    %12.6f      %12.6f      %+12.6e \n',i,m.Psect_vec(i),sim.Psect_vec(i),sim.mc_Psect_belief_vec(i));
    end     
    fprintf('Add-P belief %12.6f      %12.6f      %+12.6e \n',m.P,sim.P,sim.mc_p_belief);        
   
    fprintf('\n');
    
    fprintf('(5) Solution precision \n');       
    fprintf('eps_V              = %12.6e \n',r.diff_v);        
    fprintf('eps_M              = %12.6e \n',r.diff_M);    
    fprintf('a_min_share - W     = %8.6f \n',sim.a_min_share_workers);
    fprintf('a_max_share - W     = %8.6f \n',sim.a_max_share_workers);
    fprintf('a_min_share - F     = %8.6f \n',sim.a_min_share_firms);
    fprintf('a_max_share - F     = %8.6f \n',sim.a_max_share_firms);   
    fprintf('Share Zgrid workers = %8.6f \n',sim.z_gridpoints_worker);  
    fprintf('\n');
    
    fprintf('(6) Results \n');      
    fprintf('Share of firms - Agg          = %8.4f \n',mean(sim.allagents_share_firms));
    for i=1:s.m_grid_size
    fprintf('Share of firms - Sector %d     = %8.4f \n',i,sim.allfirms_share_vec(i));   
    end
    fprintf('X/D - Agg                     = %8.4f \n',mean(sim.X_D));
    for i=1:s.m_grid_size
    fprintf('X/D - Sector %d                = %8.4f \n',i,mean(sim.XD_vec(i)));
    end
    fprintf('NX_GDP                        =  %8.6f       \n',sim.NX_GDP);
    fprintf('Debt                          =  %8.6f       \n',sim.debt);    
    fprintf('X/GDP                         = %8.4f \n',mean(sim.X_GDP));
    fprintf('M/Abs                         = %8.4f \n',mean(sim.M_Abs));    
    fprintf('\n');
    
    fprintf('(7) Moments \n');
    fprintf('Credit/GDP                 0.188  %8.3f \n',mean(sim.ncredit_GDP));
    fprintf('X/TotalSales               0.218  %8.3f \n',mean(sim.X_TotalSales));
    fprintf('Agg share of exporters     0.197  %8.3f \n',mean(sim.allfirms_share_x));    
    fprintf('Export exit rate           0.118  %8.3f \n',mean(sim.xexit_rate));
    fprintf('Exporter sales premium     8.260  %8.3f \n',mean(sim.Xsales_NXsales));    
    fprintf('Capital/Wage bill          4.848  %8.3f \n',mean(sim.K_wagebill_ratio_withfixedcosts));     
    fprintf('Firms exit rate            0.119  %8.3f \n',mean(sim.exit_rate_firms)); 
    if s.simulate_sm_shocks==1 
        fprintf('Sales (Age 5/Age 1)        1.568  %8.3f \n',mean(sim.avg_sales_age5_age1));
    end
    fprintf('K/N (H/L)                  7.229  %8.3f \n',mean(sim.kn_med_HtoLratio));            
    fprintf('K/N (M/L)                  1.950  %8.3f \n',mean(sim.kn_med_MtoLratio));  
    fprintf('Workers per firm (H/L)     2.895  %8.3f \n',mean(sim.n_med_HtoLratio));     
    fprintf('X/Y - Sector L             0.231  %8.3f \n',mean(sim.XY_vec(1)));
    fprintf('X/Y - Sector M             0.150  %8.3f \n',mean(sim.XY_vec(2)));
    fprintf('X/Y - Sector H             0.279  %8.3f \n',mean(sim.XY_vec(end)));
    fprintf('ShareX - Sector L          0.161  %8.3f \n',mean(sim.firms_share_x_vec(1))); 
    fprintf('ShareX - Sector M          0.254  %8.3f \n',mean(sim.firms_share_x_vec(2)));
    fprintf('ShareX - Sector H          0.409  %8.3f \n',mean(sim.firms_share_x_vec(end)));
    fprintf('\n');
                
end    

mcc = mcc';

end