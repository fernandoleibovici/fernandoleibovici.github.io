%% Start

%Cleanup environment
    clear;
    close all;
    clc;    
    
%Simulation-based moments
    sim_moments = 0;
    
%% Results
    
%Baseline
    disp("Solving: Baseline");
    paper{1} = solve(1,sim_moments);

%Model with international financial autarky
    disp("  ");
    disp("Solving: Baseline with international financial autarky");
    paper{2} = solve(2,0);    

%Model with international financial autarky + closed to trade
    disp("  ");
    disp("Solving: Baseline with international financial autarky + closed to trade");
    paper{3} = solve(3,0);   

%Compute tables
    FDITtables(paper);
    FDITtables_welfare(paper);

