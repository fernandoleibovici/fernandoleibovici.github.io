%% Setup asset and productivity grids, and compute annuity market transfers

%% Productivity    

%Tauchen discretization method
%r.z_P is the transition, r.z_pi is the limiting distribution                
    [r.log_z_grid,r.z_P,r.z_pi] = AR1_tauchen(s.z_grid_size,s.z_grid_range_sd,m.log_z_rho,m.log_z_sigma,m.log_z_mu,s.z_grid_power);  
    r.z_grid = exp(r.log_z_grid); %Recovering levels from lognormal distribution    

%Productivity process statistics
    r.z_min = min(r.z_grid);
    r.z_max = max(r.z_grid);
    r.z_mean = sum(r.z_grid.*r.z_pi);

%% Productivity-specific death probabilities        

m.nu_z_grid = max(0,min(m.nu_lambda*exp(m.nu_lambda*r.z_grid)+m.nu,1));

%% Net worth

s.a_grid_size_pos = s.a_grid_size - s.a_grid_size_neg; %Number of positive gridpoints  
r.a_grid_pos = linspace(0,1,s.a_grid_size_pos);
if s.a_grid_size_neg>0
    r.a_grid_neg = linspace(0,1,s.a_grid_size_neg);        
    s.a_grid_lb = s.a_grid_lb_neg;
else
    s.a_grid_lb = s.a_grid_lb_pos;
end

%If s.a_grid_power>1, allocate more points towards lower values 
%If s.a_grid_power=1, equally spaced points
%If s.a_grid_power<1, allocate more points towards higher values
%Typically, will want to have more points toward lower values of the asset state since policy functions have more curvature at
%those points, and become more linear for higher values
    r.a_grid_pos = r.a_grid_pos.^s.a_grid_power_pos;
    if s.a_grid_size_neg>0
        r.a_grid_neg = r.a_grid_neg.^s.a_grid_power_neg;
    end

%Shift grid such that it is in the correct range
    r.a_grid_pos = r.a_grid_pos.*(s.a_grid_ub-s.a_grid_lb_pos) + s.a_grid_lb_pos; 
    if s.a_grid_size_neg>0
        r.a_grid_neg = r.a_grid_neg.*(s.a_grid_ub_neg-s.a_grid_lb_neg) + s.a_grid_lb_neg; 
    end

%Combine positive- and negative-valued grids
    if s.a_grid_size_neg>0       
        r.a_grid = [r.a_grid_neg r.a_grid_pos];
    elseif s.a_grid_size_neg==0
        r.a_grid = r.a_grid_pos;
    end

%% Get grids and export costs into matrixes and arrays    

%Asset grid matrix and array
    r.a_grid_mat = r.a_grid'*ones(1,s.z_grid_size); %First dimension controls a
    r.a(1,:,:) = r.a_grid_mat; %Second dimension controls a
    r.a(2,:,:) = r.a_grid_mat; %Second dimension controls a   

%Productivity matrix and array
    r.z_grid_mat = ones(s.a_grid_size,1)*r.z_grid'; %Second dimension controls z
    r.z(1,:,:) = r.z_grid_mat; %Third dimension controls a
    r.z(2,:,:) = r.z_grid_mat; %Third dimension controls a

%Death probability matrix and array
    m.nu_z_mat = ones(s.a_grid_size,1)*m.nu_z_grid';
    m.nu_z(1,:,:) = m.nu_z_mat;
    m.nu_z(2,:,:) = m.nu_z_mat;

%Export costs matrixes and arrays
    m.S_mat = ones(s.a_grid_size,s.z_grid_size)*m.Scost;   
    m.S(1,:,:) = m.S_mat;
    m.S(2,:,:) = m.S_mat;   

