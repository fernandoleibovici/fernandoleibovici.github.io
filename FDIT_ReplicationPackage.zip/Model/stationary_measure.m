function [measure,r,s] = stationary_measure(m,s,r)              
    
%% Computational objects

numZ = length(r.z_grid);
numA = length(r.a_grid);           
  
%Productivity
    pi = r.z_pi;

    Pmat = cell(numZ,1);
    Zp_repmat = cell(numZ,1);
    for j = 1:numZ
        Pmat{j} = ones(numA,1)*r.z_P(j,:); 
        Zp_repmat{j} = repmat(r.z_P(j,:),[numA 1]);
    end       

%Net worth    
    ap_ind_nx = squeeze(r.ap_ind(1,:,:));
    ap_ind_x  = squeeze(r.ap_ind(2,:,:));

    ap_ind_nx_cell = cell(s.z_grid_size,1);
    ap_ind_x_cell  = cell(s.z_grid_size,1);
    for j=1:s.z_grid_size
        ap_ind_nx_cell{j} = squeeze(ap_ind_nx(:,j));
        ap_ind_x_cell{j}  = squeeze(ap_ind_x(:,j) );
    end

%Export decision    
    E_nx = squeeze(r.e(1,:,:));
    E_x  = squeeze(r.e(2,:,:));        
    
%% Solution

%Initialize distribution
    Mnew_nx = zeros(numA,numZ);
    Mnew_nx(1,:) = pi'; 
    Mnew_x = zeros(numA,numZ);

%Loop    
iter = 0;
diff_M = 1;
while diff_M>s.eps_sm && iter<s.iter_sm_max

    %Update last period's distribution
        Mold_nx = Mnew_nx;
        Mold_x  = Mnew_x ;
    
    %Initialize this period's distribution
    %This is the object we solve for in each loop
        Mnew_nx = zeros(numA,numZ);
        Mnew_x  = zeros(numA,numZ);    
       
    %Slow version
%         for i=1:numA %Old asset state
%             for j=1:numZ %Old productivity state           
%                 Mnew_nx(ap_ind_nx(i,j),:) = Mnew_nx(ap_ind_nx(i,j),:) + (1-r.e(1,i,j))*Mold_nx(i,j)*r.z_P(j,:);
%                 Mnew_nx(ap_ind_x(i,j),:) = Mnew_nx(ap_ind_x(i,j),:) + (1-r.e(2,i,j))*Mold_x(i,j)*r.z_P(j,:);
% 
%                 Mnew_x(ap_ind_nx(i,j),:) = Mnew_x(ap_ind_nx(i,j),:) + r.e(1,i,j)*Mold_nx(i,j)*r.z_P(j,:);
%                 Mnew_x(ap_ind_x(i,j),:) = Mnew_x(ap_ind_x(i,j),:) + r.e(2,i,j)*Mold_x(i,j)*r.z_P(j,:);                       
%             end
%         end

    %Fast version
        for j=1:numZ %Old productivity state       
            w_Mnew_nx_nx    = accumarray(ap_ind_nx_cell{j}  ,   Mold_nx(:,j).*(1-E_nx(:,j)) );
            w_Mnew_x_nx     = accumarray(ap_ind_x_cell{j}   ,   Mold_x(:,j) .*(1-E_x(:,j))  );
            w_Mnew_nx_x     = accumarray(ap_ind_nx_cell{j}  ,   Mold_nx(:,j).*E_nx(:,j)     );
            w_Mnew_x_x      = accumarray(ap_ind_x_cell{j}   ,   Mold_x(:,j) .*E_x(:,j)      );            
            
            Mnew_nx_temp    = zeros(numA,1);
            Mnew_x_temp     = zeros(numA,1);            
            
            Mnew_nx_temp(ap_ind_nx_cell{j}) = Mnew_nx_temp(ap_ind_nx_cell{j})   + w_Mnew_nx_nx(ap_ind_nx_cell{j}); 
            Mnew_nx_temp(ap_ind_x_cell{j})  = Mnew_nx_temp(ap_ind_x_cell{j})    + w_Mnew_x_nx(ap_ind_x_cell{j}); 
            Mnew_x_temp(ap_ind_nx_cell{j})  = Mnew_x_temp(ap_ind_nx_cell{j})    + w_Mnew_nx_x(ap_ind_nx_cell{j}); 
            Mnew_x_temp(ap_ind_x_cell{j})   = Mnew_x_temp(ap_ind_x_cell{j})     + w_Mnew_x_x(ap_ind_x_cell{j});               
                        
            Mnew_nx_repmat = repmat(Mnew_nx_temp,[1 numZ]);
            Mnew_x_repmat = repmat(Mnew_x_temp,[1 numZ]);

            Mnew_nx = Mnew_nx + Mnew_nx_repmat.*Zp_repmat{j};
            Mnew_x = Mnew_x + Mnew_x_repmat.*Zp_repmat{j};  
        end

    %Death
        Mnew_nx = (1-m.nu_z_mat).*Mnew_nx;
        Mnew_x  = (1-m.nu_z_mat).*Mnew_x;

    %Birth
    %Fixed population
        if sum(m.nu_z_grid)>0
            Mnew_nx(m.a_new,:) = Mnew_nx(m.a_new,:) + r.z_pi'.*m.nu_z_grid';
        end            
       
    %Convergence measure
        diff_M = max(max(abs(Mnew_nx(:)-Mold_nx(:))),max(abs(Mnew_x(:)-Mold_x(:)))); 
        
    %Iteration number
        iter = iter + 1;

end
r.diff_M = diff_M;
r.iter_M = iter;

%Store stationary measures
    measure(1,:,:) = Mnew_nx;
    measure(2,:,:) = Mnew_x ;

end
