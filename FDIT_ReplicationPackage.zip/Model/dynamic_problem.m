function r = dynamic_problem(m,s,r,sp_nx,sp_x)

%% Income
%States @ static problem: (net worth x productivity x exporter decision x occupation)
%States @ dynamic problem: (past export decision x net worth x productivity)

%Income
    for i = 1:s.a_grid_size
        for j = 1:s.z_grid_size  

            %Find income of agents with net worth a(i) and productivity z(j)
            %Last period export decision    = {X,NX}    => First element of 3-dimensional vectors
            %This period's export decision  = {X,NX}    => Variable name
            %Proceed recursively to find max income between occupation and being a worker
            %If export today, do not consider possibility of choosing to be a worker
                r.y_nx(1,i,j)   = m.w; %Current non-exporter
                r.m_nx(1,i,j)   = 1;
                
                r.y_nx(2,i,j)   = m.w; %Current non-exporter
                r.m_nx(2,i,j)   = 1;
                
                r.y_x(1,i,j)    = 0;   %Current exporter
                r.m_x(1,i,j)    = 0;
                
                r.y_x(2,i,j)    = 0;   %Current exporter
                r.m_x(2,i,j)    = 0;
                
            %Iterate across occupations
            %Static choice between occupation and being a worker
                for m_sect=1:s.m_grid_size
                    [r.y_nx(1,i,j),ind] = max([r.y_nx(1,i,j)    sp_nx.pi(i,j,1,m_sect)]);
                    r.m_nx(1,i,j) = (2-ind)*r.m_nx(1,i,j) + (ind-1)*(1+m_sect);
                    
                    [r.y_nx(2,i,j),ind] = max([r.y_nx(2,i,j)    sp_x.pi(i,j,1,m_sect)]);
                    r.m_nx(2,i,j) = (2-ind)*r.m_nx(2,i,j) + (ind-1)*(1+m_sect);
                    
                    [r.y_x(1,i,j),ind] = max([r.y_x(1,i,j)     sp_nx.pi(i,j,2,m_sect)]);
                    r.m_x(1,i,j) = (2-ind)*r.m_x(1,i,j) + (ind-1)*(1+m_sect);
                    
                    [r.y_x(2,i,j),ind] = max([r.y_x(2,i,j)     sp_x.pi(i,j,2,m_sect)]);
                    r.m_x(2,i,j) = (2-ind)*r.m_x(2,i,j) + (ind-1)*(1+m_sect);
                end
                
        end
    end

%Workers conditional on current export decision
    r.worker_x  = r.m_x  == 1; 
    r.worker_nx = r.m_nx == 1;

%Trade costs array
    TC          = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size);
    TC(1,:,:)   = m.Scost*((1-m.eta_S)+(1+m.r)*m.eta_S);

%% Dynamic problem: value functions and policy functions   
 
%Initialize computational objects
    %Consumption conditional on net worth decision
        c_x_temp    = (1/m.P)*(r.y_x    + m.Pi + m.P*r.a*(1+m.r) - m.w*TC   - r.T); 
        c_nx_temp   = (1/m.P)*(r.y_nx   + m.Pi + m.P*r.a*(1+m.r)            - r.T);         
        
        c_x     = zeros(s.a_grid_size,s.x_grid_size,s.a_grid_size,s.z_grid_size);
        c_nx    = zeros(s.a_grid_size,s.x_grid_size,s.a_grid_size,s.z_grid_size);       
        for i=1:s.a_grid_size
            c_x(i,:,:,:)    = c_x_temp  - r.a_grid(i)*(1-m.nu_z);   
            c_nx(i,:,:,:)   = c_nx_temp - r.a_grid(i)*(1-m.nu_z); 
        end

    %Utility
        if m.gamma~=1
            u_x     = (c_x .^(1-m.gamma))./(1-m.gamma); 
            u_nx    = (c_nx.^(1-m.gamma))./(1-m.gamma); 
        elseif m.gamma==1
            u_x  = log(c_x);
            u_nx = log(c_nx);
        end
        u_x( c_x <=0)   = -1e50;        
        u_nx(c_nx<=0)   = -1e50;
        
        %Permute indexes
        %From: (a',e,a,z)
        %To  : (a',z,a,e)
            u_x_perm    = permute(u_x ,[1 4 3 2]); 
            u_nx_perm   = permute(u_nx,[1 4 3 2]);               

    %Productivity
    %Transpose of transition matrix
        r.z_P_T = zeros(size(r.z_P));
        for j=1:s.z_grid_size
            r.z_P_T(:,j) = r.z_P(j,:)';
        end   
    
%Initialize value function objects                
    e = zeros(s.z_grid_size,s.a_grid_size,s.x_grid_size);

    v = zeros(s.z_grid_size,s.a_grid_size,s.x_grid_size);  
    for j=1:s.z_grid_size
        for i=1:s.a_grid_size  
            for k=1:s.x_grid_size                          
                v(j,i,k) = (1/(1-m.beta*(1-m.nu_z_grid(j))))*u_nx(i,k,i,j);
            end
        end
    end
    
%Loop    
    e_old           = e;
    v_old           = v; 
    ap_ind_x_old    = zeros(s.z_grid_size,s.a_grid_size,s.x_grid_size);  
    ap_ind_nx_old   = zeros(s.z_grid_size,s.a_grid_size,s.x_grid_size);
    
    diff_v          = 1;
    diff_e          = 1;
    diff_a          = 1;    
    iter            = 0;
    
    while max(diff_v,max(diff_e,diff_a))>s.eps_dp_vfi && iter<s.iter_dp_vfi_max

        iter = iter + 1;        

        %Compute continuation value given e' for every (a',z')
        %Continuation values are independent of a and e (but depend on a', z, and e')   
            v_x     = u_x_perm  + (1-m.nu_z_mat).*m.beta.*(v_old(:,:,2)')*r.z_P_T; %(a',z,a,e) = (a',z,a,e) + (a,z) x (a,z) x (z,z)
            v_nx    = u_nx_perm + (1-m.nu_z_mat).*m.beta.*(v_old(:,:,1)')*r.z_P_T; %(a',z,a,e) = (a',z,a,e) + (a,z) x (a,z) x (z,z)
     
        %Net worth choice
        %Value function given optimal net worth choice, conditional on export decision     
            [v_x_max ,ap_ind_x ]    = max(v_x );
            [v_nx_max,ap_ind_nx]    = max(v_nx); 
            v_x_max     = squeeze(v_x_max );
            v_nx_max    = squeeze(v_nx_max);

        %Export entry choice
            e = v_x_max > v_nx_max;         

        %Value function given optimal export entry choice
            v = v_x_max.*e + v_nx_max.*(1-e);                        

        %Convergence measures
            diff_e          = max(abs(e(:)-e_old(:)));
            diff_v          = max(abs(v(:)-v_old(:)));
            diff_a          = max(abs(ap_ind_x(:)-ap_ind_x_old(:))+abs(ap_ind_nx(:)-ap_ind_nx_old(:)));            

        %Update   
            e_old           = e;
            v_old           = v;    
            ap_ind_x_old    = ap_ind_x;
            ap_ind_nx_old   = ap_ind_nx;              

    end
    
    %Permute
    %From: (z,a,e) 
    %To  : (e,a,z)
        v           = permute(v,[3 2 1]); 
        e           = permute(e,[3 2 1]);    
        ap_ind_x    = permute(squeeze(ap_ind_x ),[3 2 1]);    
        ap_ind_nx   = permute(squeeze(ap_ind_nx),[3 2 1]);    

%Store output    
    r.v             = v;
    r.e             = e;
    r.m             = r.m_x.*r.e + r.m_nx.*(1-r.e);
    r.y             = r.y_x.*r.e + r.y_nx.*(1-r.e);
    r.worker        = r.m==1;
    r.ap_ind_x      = squeeze(ap_ind_x);
    r.ap_ind_nx     = squeeze(ap_ind_nx);    
    r.ap_ind        = r.ap_ind_x.*r.e + r.ap_ind_nx.*(1-r.e);
    r.ap            = r.a_grid(r.ap_ind);
    r.diff_v        = diff_v;      
    r.diff_a        = diff_a;
    r.diff_e        = diff_e;
    r.iter          = iter;
    
%Compute policy functions given r.e, r.ap_ind_x, and r.ap_ind_nx
    r.c     = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size);    
    for k=1:s.x_grid_size
        for i=1:s.a_grid_size
            for j=1:s.z_grid_size
                r.c(k,i,j)  = r.e(k,i,j)    *(1/m.P)*(r.y_x(k,i,j)  + m.Pi + m.P*r.a_grid(i)*(1+m.r) - m.P*r.ap(k,i,j)*(1-m.nu_z_grid(j)) - r.T - m.w*TC(k,i,j) ) + ...
                              (1-r.e(k,i,j))*(1/m.P)*(r.y_nx(k,i,j) + m.Pi + m.P*r.a_grid(i)*(1+m.r) - m.P*r.ap(k,i,j)*(1-m.nu_z_grid(j)) - r.T);
            end
        end
    end           

%Occupation status
%=0 if worker
%=1 if sector 1 and non-exporter
%=2 if sector 1 and exporter
%=3 if sector 2 and non-exporter
%=4 if sector 2 and exporter
    r.status = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size);
    for k = 1:s.x_grid_size 
        for i = 1:s.a_grid_size
            for j = 1:s.z_grid_size                
                                
                if r.m(k,i,j)==1
                    r.status(k,i,j) = 0;
                end                                        
                for m_sect=1:s.m_grid_size
                   if r.m(k,i,j)==m_sect+1
                       r.status(k,i,j) = (2*m_sect - 1) + r.e(k,i,j);
                   end
                end

            end
        end 
    end       

%% Rest of variables                   

r.k_ku          = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size);
r.mu            = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size);
r.ph            = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size);
r.yh            = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size);
r.pf            = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size,m.X_countries);
r.yf            = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size,m.X_countries);
r.n             = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size);
r.x             = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size);
r.k             = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size);
r.pi            = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size);
r.pfyf_total    = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size);
r.X_Fcost_total = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size);
r.h             = zeros(s.x_grid_size,s.a_grid_size,s.z_grid_size,s.m_grid_size+1);

for i = 1:s.a_grid_size
    for j = 1:s.z_grid_size   
        if r.worker(1,i,j)==0 && r.m(1,i,j)~=0
            r.k_ku(1,i,j)           = sp_nx.k_ku(           i,j,r.e(1,i,j)+1,r.m(1,i,j)-1   );
            r.mu(1,i,j)             = sp_nx.mu(             i,j,r.e(1,i,j)+1,r.m(1,i,j)-1   );
            r.ph(1,i,j)             = sp_nx.ph(             i,j,r.e(1,i,j)+1,r.m(1,i,j)-1   );
            r.yh(1,i,j)             = sp_nx.yh(             i,j,r.e(1,i,j)+1,r.m(1,i,j)-1   );
            r.pf(1,i,j,:)           = sp_nx.pf(             i,j,r.e(1,i,j)+1,r.m(1,i,j)-1,: );
            r.yf(1,i,j,:)           = sp_nx.yf(             i,j,r.e(1,i,j)+1,r.m(1,i,j)-1,: );                
            r.n(1,i,j)              = sp_nx.n(              i,j,r.e(1,i,j)+1,r.m(1,i,j)-1   );
            r.x(1,i,j)              = sp_nx.x(              i,j,r.e(1,i,j)+1,r.m(1,i,j)-1   );
            r.k(1,i,j)              = sp_nx.k(              i,j,r.e(1,i,j)+1,r.m(1,i,j)-1   );
            r.pi(1,i,j)             = sp_nx.pi(             i,j,r.e(1,i,j)+1,r.m(1,i,j)-1   );
            r.pfyf_total(1,i,j)     = sp_nx.pfyf_total(     i,j,r.e(1,i,j)+1,r.m(1,i,j)-1   );
            r.X_Fcost_total(1,i,j)  = sp_nx.X_Fcost_total(  i,j,r.e(1,i,j)+1,r.m(1,i,j)-1   );
            for k = 1:s.m_grid_size+1
                r.h(1,i,j,k)        = sp_nx.h(              i,j,r.e(1,i,j)+1,r.m(1,i,j)-1,k );
            end
        end     
        if r.worker(2,i,j)==0 && r.m(2,i,j)~=0
            r.k_ku(2,i,j)           = sp_x.k_ku(            i,j,r.e(2,i,j)+1,r.m(2,i,j)-1   );
            r.mu(2,i,j)             = sp_x.mu(              i,j,r.e(2,i,j)+1,r.m(2,i,j)-1   );
            r.ph(2,i,j)             = sp_x.ph(              i,j,r.e(2,i,j)+1,r.m(2,i,j)-1   );
            r.yh(2,i,j)             = sp_x.yh(              i,j,r.e(2,i,j)+1,r.m(2,i,j)-1   );
            r.pf(2,i,j,:)           = sp_x.pf(              i,j,r.e(2,i,j)+1,r.m(2,i,j)-1,: );
            r.yf(2,i,j,:)           = sp_x.yf(              i,j,r.e(2,i,j)+1,r.m(2,i,j)-1,: );                
            r.n(2,i,j)              = sp_x.n(               i,j,r.e(2,i,j)+1,r.m(2,i,j)-1   );
            r.x(2,i,j)              = sp_x.x(               i,j,r.e(2,i,j)+1,r.m(2,i,j)-1   );
            r.k(2,i,j)              = sp_x.k(               i,j,r.e(2,i,j)+1,r.m(2,i,j)-1   );
            r.pi(2,i,j)             = sp_x.pi(              i,j,r.e(2,i,j)+1,r.m(2,i,j)-1   );
            r.pfyf_total(2,i,j)     = sp_x.pfyf_total(      i,j,r.e(2,i,j)+1,r.m(2,i,j)-1   );
            r.X_Fcost_total(2,i,j)  = sp_x.X_Fcost_total(   i,j,r.e(2,i,j)+1,r.m(2,i,j)-1   );
            for k = 1:s.m_grid_size+1
                r.h(2,i,j,k)        = sp_x.h(               i,j,r.e(2,i,j)+1,r.m(2,i,j)-1,k );
            end            
        end      
    end
end 

end