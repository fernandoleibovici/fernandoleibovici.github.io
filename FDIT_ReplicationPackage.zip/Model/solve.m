function results = solve(ver,base) 

%% Start

%Delete auxiliary files used in previous runs    
    if exist('ss_prices.mat','file')==2
        delete('ss_prices.mat');
    end
    if exist('vfi_objects.mat','file')==2
        delete('vfi_objects.mat');
    end
    if exist('sm_objects.mat','file')==2
        delete('sm_objects.mat');
    end
  
%% Model version

%Economies
%=1 for baseline
%=2 for international financial autarky + open to trade
%=3 for international financial autarky + closed to trade

%Select model used
    s_opt.ver = ver;
    
%% Control panel

%GE
%General equilibrium prices
%=0 if compute results using predetermined prices
%=1 if solve for GE prices, then compute results using GE prices (fsolve)
    s_opt.GE           = 0;
    
%Counterfactuals
%=0 if only compute baseline calibration
%=1 if compute baseline calibration and counterfactuals
    s_opt.counterfactuals = 1;    
    
%Model
    %Version
    %=1 => Baseline
    %=2 => 4 export destinations
        s_opt.solve       = 1;              
                                            
    %International financial integration
        if s_opt.ver==2 || s_opt.ver==3
            s_opt.ifi = 0;
        else
            s_opt.ifi = 1;      
        end
        
    %Closed economy    
        if s_opt.ver==3
            s_opt.notrade = 1;
        else
            s_opt.notrade = 0; 
        end
        
    %Number of tradable sectors
        s_opt.tradablesectors = 3;
               
    %Scale
        s_opt.B = 100;
        
    %Simulated moments for base economy
        s_opt.base = base;
        
%Options        
    %Workspace
        s_opt.save_workspace  = 0;
    
%% Solve model

%GE vector
%Parameter vector
    s_opt.prices_guess = 0;
    if s_opt.solve==1
        if s_opt.ver==1
            s_opt.prices_guess = exp([2.062884902430195,1.320047708072445,1.157163709037672,1.081572073874044,-1.270069619882158,-0.312859254679274,-0.440463531456670]);
            v = [-0.164278323535441  -1.744219  -0.874459411079429  -0.411100  -2.105630  +1.705066  -1.561643  -0.067239  -2.050376  -0.013402  +1.634807  +1.755956  +0.075133  +0.455053  -0.847717499199136  +3.679554];
        elseif s_opt.ver==2
            s_opt.prices_guess = exp([2.063081005850494,1.321043321977994,1.158253700445075,1.083139752669798,-1.270575912112527,-0.313734021230419,-0.441945665881691,-0.273354665090807]);
            v = [-0.164278323535441  -1.744219  -0.874459411079429  -0.411100  -2.105630  +1.705066  -1.561643  -0.067239  -2.050376  -0.013402  +1.634807  +1.755956  +0.075133  +0.455053  -0.847717499199136  +3.679554];
        elseif s_opt.ver==3
            s_opt.prices_guess = exp([-0.629778859683893,-0.805275535729530,-0.884050660309514,-1.362425531372437,-0.400332815255330,-0.548693051036308,-0.189222937032106]);
            v = [-0.164278323535441  -1.744219  -0.874459411079429  -0.411100  -2.105630  +1.705066  -1.561643  -0.067239  -2.050376  -0.013402  +1.634807  +1.755956  +0.075133  +0.455053  -0.847717499199136  +3.679554];
        end
    end
    
%Compute results   
    output = mainFN(v,s_opt);
    
%% End

results = output;

end
