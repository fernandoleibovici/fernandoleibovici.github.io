function output = mainFN(v,s_opt)

%Parameter vector
%Input vector v expresses parameters after taking logs
%Here we compute exp(v) to obtain levels of the parameters
    v = exp(v);
    
%Replace infinite values with large ones    
	v(isinf(v)) = 100000;
	
%% Control panel

%Solution
    s.solve = s_opt.solve;
                            
%General equilibrium prices
%=0 if compute results using predetermined prices
%=1 if solve for GE prices, then compute results using GE prices (fsolve)
    s.GE            = s_opt.GE;
    
%Counterfactuals
%=0 if only compute baseline calibration
%=1 if compute baseline calibration and counterfactuals
    s.counterfactuals = s_opt.counterfactuals;
    
%Save workspace
%=0 if don't save workspace
%=1 if save workspace
    s.workspace_save = s_opt.save_workspace;
    
%Compute additional results
%>=1 if compute random-sample-based statistics
% =2 if compute tables to export to Excel
    s.extraresults = 0;

%Display
    s.display = 0;      
    
%Clear memory
    s.clearmemory = 1;
    
%% Parameters

%International financial integration
    s.ifi = s_opt.ifi;       
    
%Closed economy
%=0 if open economy
%=1 if closed economy   
    s.notrade = s_opt.notrade; 
                                  
%Avg. productivity level
    m.z_mean = 1;
    m.B      = s_opt.B;                                   
                                 
%Calibrated     
    m.beta          = v(1);                 %Discount factor
    m.theta         = v(2);                 %Loan per unit of capital available to firms          
    m.alpha_l       = v(3);                 %Capital share in labor-intensive sector
    m.alpha_h       = v(4);                 %Capital share in capital-intensive sector
    m.MH1           = v(5);                 %Fixed cost to operate in capital-intensive sector
    m.tau           = v(6);                 %Iceberg trade cost
    m.Scost         = v(7);                 %Sunk export entry cost
    m.Fcost         = v(8);                 %Fixed export cost
    m.log_z_sigma   = v(9);                 %Std dev of productivity distribution 
    m.log_z_rho     = v(10);                %Persistence

%Pre-assigned          
    m.sigma         = 4;             %Elasticity of substitution across varieties
    m.gamma = 1;                     %Risk aversion        
    m.delta         = 0.06;          %Capital depreciation rate      
    m.a_initial     = 0;             %Asset-holdings of new entrepreneurs
    m.Prow          = 1;             %Price index in the rest of the world 
    m.Pm            = 1;             %Price of imported goods    
    m.Yrow          = v(16)*m.B;     %Output in the rest of the world   
    m.nu            = 0;             %Death probability
    m.nu_lambda     = 0;             %Parameter on productivity-specific death rate function 

%No trade
    if s.notrade==1
       m.tau        = 1000;
       m.Scost      = 1000;
       m.Fcost      = 1000;
       m.omega_m    = 0;
       m.Pm         = 1000;
       m.Yrow       = 0.0001;
    end    
    
%Sector-specific parameters   
    s.m_grid_size = s_opt.tradablesectors;

    %3 sectors
        if s.m_grid_size==3
            m.alpha_m = v(15);
			m.alpha_l = v(3);
            m.alpha_vec     = [m.alpha_l  m.alpha_m   m.alpha_h];
            m.M1_vec        = [0            0                           m.MH1    ];
            m.tau_vec       = [m.tau        v(11)                       v(12)    ];
            m.F_vec         = [m.Fcost      v(13)                       v(14)    ];
        end
        
    %Rest of the sector-specific parameters
        m.theta_vec(1:s.m_grid_size) = m.theta;
        m.delta_vec(1:s.m_grid_size) = m.delta;
        m.sigma_vec(1:s.m_grid_size) = m.sigma;
        m.A_vec(1:s.m_grid_size)     = 1;       %Sectoral productivities
                    
%Sectoral CES aggregator
    %Weight on imported varieties    
        if s.notrade==0  
                m.omega_m_vec(1:s.m_grid_size) = 1;
        elseif s.notrade==1
                m.omega_m_vec(1:s.m_grid_size) = 0;
        end

    %Import prices     
        m.Pm_vec(1:s.m_grid_size) = m.Pm*m.tau_vec;        
        
    %Weight on domestic varieties
        m.omega_h_sec_vec(1:s.m_grid_size) = 1;         
      
%Productivity   
%Log-normal distribution
%Normalize average productivity to m.z_mean      
    m.log_z_mu = log(m.z_mean)-(m.log_z_sigma^2)*(1/((1-m.log_z_rho^2)))*(1/2);  

%Extended model parameters
    m.eta_F                         = 1;            %Share of fixed export costs paid in advance
    m.eta_S                         = 1;            %Share of sunk export costs paid in advance
    m.eta_M                         = 0;            %Share of fixed operation costs paid in advance
    m.X_countries                   = 1;            %Number of foreign countries
    m.X_tau(1:m.X_countries,:)      = m.tau_vec;    %Destination-specific iceberg trade costs
    m.X_Fcost(1:m.X_countries,:)    = ones(1:m.X_countries,1)*m.F_vec; %Destination-specific fixed export costs
    m.X_Yrow(1:m.X_countries,1)     = m.Yrow;       %Output in the rest of the world
    m.X_Prow(1:m.X_countries,1)     = m.Prow;       %Price indexes in the rest of the world
    m.theta_wc = 1;

%Final goods
    %Sectoral shares
	%First s.m_grid_size sectors 	=> Tradable sectors
	%Sector s.m_grid_size + 1 		=> Non-tradable sector
        m.phi_fin_vec = [0.07 0.14 0.07 0.72];
        m.phi_fin_vec = m.phi_fin_vec./(sum(m.phi_fin_vec));   
        
%Intermediates and varieties        
    %Share of intermediates in the production of sectoral varieties
	%First s.m_grid_size sectors 	=> Tradable sectors
	%Sector s.m_grid_size + 1 		=> Non-tradable sector	
        m.phi_int_vec = [0.84 0.67 0.73 0.42];     
       
    %DRS
        m.eta_drs_1_vec = (1-m.alpha_vec).*(1-m.phi_int_vec(1:end-1));       
        m.eta_drs_2     = 1; %Coefficient on capital, labor, and intermediates
                
    %Composition of intermediate good bundles in the production of sectoral varieties
	%First s.m_grid_size sectors 	=> Tradable sectors
	%Sector s.m_grid_size + 1 		=> Non-tradable sector	    
    %Column = Sector that demands intermediates
    %Row = Sector from which intermediates are demanded
            m.gamma_mat(1,:) = [0.19	0.01	0.02	0.05];
            m.gamma_mat(2,:) = [0.06	0.29	0.04	0.12];
            m.gamma_mat(3,:) = [0.08	0.19	0.27	0.13];
            m.gamma_mat(4,:) = [0.68	0.50	0.67	0.70];  
            m.gamma_mat = m.gamma_mat./(ones(4,1).*sum(m.gamma_mat,1));
        
    %Sector used as intermediate base
        m.int_base = 1;
                          
%Non-tradable productivity
    m.z_NT = 1*m.B^(1-m.phi_int_vec(end)); %Productivity of NT sector
        
%Interest rate                  
    m.r = 0.0554; 

%% Solution options

%GE iterations
%Maximum number of solver attempts to find GE prices
    s.iter_GE_max = 6; 
               
%Grids
    %Productivity  
        s.z_grid_size   = 250;      %Productivity grid size
        s.z_grid_power      = 1/6;      %Curvature parameter to control distance across grid points (baseline=1/2)       
        s.z_grid_range_sd   = 4;        %Range of productivity grid (only for Tauchen)

    %Assets       
        s.a_grid_size   = 250;      %Asset grid size 
        s.a_grid_size_neg   = 0;        %Number of negative asset values, if assets can be negative

        s.a_grid_power_pos  = 3;        %Curvature parameter to control distance across grid points for a>=0 (baseline=2)
        s.a_grid_power_neg  = 1/2;      %Curvature parameter to control distance across grid points for a<0 

        s.a_grid_ub         = 4*m.B;    %Upper bound on asset grid            
        s.a_grid_lb_pos     = 0;        %Lowest positive value of net worth     
        s.a_grid_ub_neg     = -1e-3;    %Highest negative value of net worth       
        s.a_grid_lb_neg     = -2;       %Lowest negative value of net worth
        
    %Export status
        s.x_grid_size = 2;      

%Solution algorithm    
%Value function iteration
    s.eps_dp_vfi            = 1e-7; %Convergence criteria
    s.iter_dp_vfi_max       = 2000;  
                       
%Stationary measure
    s.eps_sm                = 1e-7; %Convergence criteria
    s.iter_sm_max           = 10000; 
    s.simulate_sm_shocks    = 0;  
    
%Simulation based on stationary measure
    s.N2      = 2000; 
    s.T2      = 13; 
    s.K2      = 1;      %# of simulations
    s.T2_burn = 50;
    s.seed    = 22;   
    
%Display      
    s.display_original  = s.display;
    
%Optimizer options
%Algorithm options 
    s.LM_GE             = 0.01;
    s.TolX_GE           = 1e-6;
    s.TolFun_GE         = 1e-6;
    s.MaxFunEvals_GE    = 500;  
    
%% Setup grids

setup_state_grids;
       
%% Solve baseline

m.w = 0.01;
m.Psect_vec = [1 1 1];
m.Ysect_vec = [1 1 1]; 

%GE vector
    %Initial values
        if s_opt.notrade==0
            solver.z = [m.w m.Psect_vec m.Ysect_vec]; 
        elseif s_opt.notrade==1
            solver.z = [m.Psect_vec m.Ysect_vec];            
        end
        
        %Interest rate
            if s.ifi==0 && m.theta~=0
                solver.z(end+1) = (m.r+(m.delta-1e-6))/(0.3-m.r-(m.delta-1e-6));
            end        
        
    %Load from solve.m, if available
        if sum(s_opt.prices_guess)~=0
            solver.z = s_opt.prices_guess;
        end
       
    %Overwrite with last iteration, if available
        solver.z_original = solver.z;
        if exist('ss_prices.mat','file')==2
            load ss_prices.mat;
            solver.z = ss_prices;
        end        
        
    %Apply log to price vector (solve in logs)
        solver.z = log(solver.z);                   

%Find general equilibrium prices and quantities
    converged = 0;
    if s.GE>=1    

        GE_stop = 0;
        iter_GE = 0;

        %Loop
            InitDamping = {0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01,0.01}; 
            FDS         = {0.001,0.01,0.001,0.01,0.001,0.01,0.001,0.01,0.001,0.01,0.001,0.01};  
            while GE_stop==0          

                iter_GE = iter_GE+1;      
                               
                %Options
						if iter_GE<=3
							s.options = optimoptions(@fsolve,'Algorithm','trust-region','Display','iter','StepTolerance',1e-6,'FunctionTolerance',1e-6,'MaxFunctionEvaluations',s.MaxFunEvals_GE,...
									 'FiniteDifferenceStepSize',FDS{iter_GE},'FiniteDifferenceType','central'...
									 ,'UseParallel',true);                    
						elseif iter_GE>3 && iter_GE<=6
							  s.options = optimoptions(@fsolve,'Display','iter','StepTolerance',1e-6,'FunctionTolerance',1e-6,'MaxFunctionEvaluations',s.MaxFunEvals_GE,...
										  'Algorithm','levenberg-marquardt','InitDamping',InitDamping{iter_GE},'FiniteDifferenceStepSize',FDS{iter_GE},'FiniteDifferenceType','central'...
										  ,'ScaleProblem','jacobian','UseParallel',true);    
                        elseif iter_GE>6 && iter_GE<=9
							s.options = optimoptions(@fsolve,'Algorithm','trust-region','Display','iter','StepTolerance',1e-6,'FunctionTolerance',1e-6,'MaxFunctionEvaluations',s.MaxFunEvals_GE,...
									 'FiniteDifferenceStepSize',FDS{iter_GE},'FiniteDifferenceType','central'...
									 ,'UseParallel',true);     
						elseif iter_GE>9 && iter_GE<=12
							  s.options = optimoptions(@fsolve,'Display','iter','StepTolerance',1e-6,'FunctionTolerance',1e-6,'MaxFunctionEvaluations',s.MaxFunEvals_GE,...
										  'Algorithm','levenberg-marquardt','InitDamping',InitDamping{iter_GE},'FiniteDifferenceStepSize',FDS{iter_GE},'FiniteDifferenceType','central'...
										  ,'ScaleProblem','jacobian','UseParallel',true);                                    
						end                                 

                %Solve 
                    [solver.z,solver.fval,solver.exitflag,solver.output] = fsolve(@(x)GEsolve(x,m,s,r),solver.z,s.options);     
                    
                %Exit if converged or if reached max number of iterations                      
                    if solver.exitflag>=1 
                        GE_stop     = 1;
                        converged   = 1;
                    elseif iter_GE==s.iter_GE_max
                        GE_stop     = 1;
                        converged   = 0;    
                    end  
                
            end    

        %Update ss_prices
            if converged==1
                ss_prices = exp(solver.z); 
                save('ss_prices.mat','ss_prices')  
            elseif converged==0
                if exist('ss_prices.mat','file')==2
                    delete ss_prices.mat;
                end
            end            

    end     

%Compute solution
    %Special simulation specifications if baseline economy
        if s_opt.base==1
            s.N2      = 2000; %200000; 
            s.T2      = 13; 
            s.K2      = 1; %250;  %# of simulations
            s.T2_burn = 50;
            s.seed    = 22;
        end
    
    %Store s.extraresults
        s.extraresults_original     = s.extraresults;
    
    %Update options to compute and display results
        s.display                   = 0;
        s.simulate_sm_shocks        = 1;
        s.extraresults              = 2;
    
    %Solve model
        [~,sim,r,s,m]               = GEsolve(solver.z,m,s,r);   
    
    %Restore options
        s.display                   = s.display_original;
        s.simulate_sm_shocks        = 0;        
        s.extraresults              = s.extraresults_original;
    
    %Restore simulation specifications if baseline economy
        if s_opt.base==1
            s.N2      = 2000; 
            s.T2      = 13; 
            s.K2      = 1;      %# of simulations
            s.T2_burn = 50;
            s.seed    = 22;    
        end
        
    %Display
        disp("Solved: Baseline");
        
%% Solve counter-factuals

if s.counterfactuals==1   
   
    if s_opt.ver==1
        exp_theta = [0 0.931632];
        exp_solver{1}.z = [2.045411780843662,1.311694074045700,1.164664770086975,1.093444943113402,-1.275178216852865,-0.337630657112954,-0.472453948911124];
        exp_solver{2}.z = [2.163948780164092,1.369519175390706,1.106930048009340,1.003700256266310,-1.244446069752556,-0.165336037597026,-0.243481781444299];
    
        cf_cnt = numel(exp_theta);
    elseif s_opt.ver==2
        exp_theta = [0 0.931632];
        exp_solver{1}.z = [2.040967148600215,1.308432067651239,1.163529704418294,1.092776934388525,-1.277438929143899,-0.342079828624718,-0.476828174285216,-0.273354665090807];
        exp_solver{2}.z = [2.108495123535147,1.364245239703572,1.141376422333231,1.060144026440928,-1.282865320489317,-0.252446296575171,-0.364491928011020,0.451292399046756];
    
        cf_cnt = numel(exp_theta);
    elseif s_opt.ver==3
        exp_theta = [0 0.931632];
        exp_solver{1}.z = [-0.615835432164687,-0.779007419505119,-0.854790302743150,-1.37783513533488,-0.428033578005816,-0.579327747158599,-0.189222937032106];
        exp_solver{2}.z = [-0.641623994773526,-0.857059818386479,-0.939309487085265,-1.35109902488806,-0.349181064632928,-0.494359413371533,0.453650472733160];
        cf_cnt = numel(exp_theta);
    end  
    
    for i = 1:cf_cnt

        %Update
            exp_m{i,1}          = m;
            exp_m{i}.theta      = exp_theta(i);
            exp_m{i}.theta_vec(1:s.m_grid_size)  = exp_theta(i);
            
        %Find general equilibrium prices
            if s.GE==1          
                
                converged = 0;
                GE_stop = 0;
                iter_GE = 0;                    
                
                while GE_stop==0
                    
                    iter_GE = iter_GE+1;   
                    
					%Options
						if iter_GE<=3
							s.options = optimoptions(@fsolve,'Algorithm','trust-region','Display','iter','StepTolerance',1e-6,'FunctionTolerance',1e-6,'MaxFunctionEvaluations',s.MaxFunEvals_GE,...
									 'FiniteDifferenceStepSize',FDS{iter_GE},'FiniteDifferenceType','central'...
									 ,'UseParallel',true);                    
						elseif iter_GE>3 && iter_GE<=6
							  s.options = optimoptions(@fsolve,'Display','iter','StepTolerance',1e-6,'FunctionTolerance',1e-6,'MaxFunctionEvaluations',s.MaxFunEvals_GE,...
										  'Algorithm','levenberg-marquardt','InitDamping',InitDamping{iter_GE},'FiniteDifferenceStepSize',FDS{iter_GE},'FiniteDifferenceType','central'...
										  ,'ScaleProblem','jacobian','UseParallel',true);    
                        elseif iter_GE>6 && iter_GE<=9
							s.options = optimoptions(@fsolve,'Algorithm','trust-region','Display','iter','StepTolerance',1e-6,'FunctionTolerance',1e-6,'MaxFunctionEvaluations',s.MaxFunEvals_GE,...
									 'FiniteDifferenceStepSize',FDS{iter_GE},'FiniteDifferenceType','central'...
									 ,'UseParallel',true);     
						elseif iter_GE>9 && iter_GE<=12
							  s.options = optimoptions(@fsolve,'Display','iter','StepTolerance',1e-6,'FunctionTolerance',1e-6,'MaxFunctionEvaluations',s.MaxFunEvals_GE,...
										  'Algorithm','levenberg-marquardt','InitDamping',InitDamping{iter_GE},'FiniteDifferenceStepSize',FDS{iter_GE},'FiniteDifferenceType','central'...
										  ,'ScaleProblem','jacobian','UseParallel',true);                                    
						end           
                                
                    %Solve
                        [exp_solver{i}.z,exp_solver{i}.fval,exp_solver{i}.exitflag,exp_solver{i}.output] = fsolve(@(x)GEsolve(x,exp_m{i},s,r),exp_solver{i}.z,s.options); 
                    
                    %Exit if converged or if reached max number of iterations                      
                        if (exp_solver{i}.exitflag>=1 && exp_solver{i}.output.iterations>=2) 
                            GE_stop = 1;
                            converged = 1;
                        elseif iter_GE==s.iter_GE_max
                            GE_stop = 1;
                            converged = 0;  
                        end

                end   
                
            end

        %Compute solution based on stationary measure
            s.display               = 0;
            s.simulate_sm_shocks    = 1;
            s.extraresults          = 2;

            [exp_mcc{i,1},exp_sim{i,1},r_temp,s_temp,exp_m{i,1}] = GEsolve(exp_solver{i}.z,exp_m{i},s,r);
            
            s.display            = s.display_original;            
		    s.simulate_sm_shocks = 0;
            s.extraresults       = 0; 
            
            disp(['Solved CF' num2str(i)]);

    end  
               
end
        
%% Save workspace

if s.workspace_save==1
    time_tag = clock; %year, month, day, hour, minute
    filename = ['workspace_' num2str(time_tag(1)) '_' num2str(time_tag(2)) '_' num2str(time_tag(3)) '_' num2str(time_tag(4))...
                    '_' num2str(time_tag(5)) '.mat'];   
    sim_shocks = [];
    save(filename,'-v7.3');
end

%% Output

output.sim = sim;
output.r   = r;
output.m   = m;

if s.counterfactuals==1
    output.exp_sim = exp_sim;
    output.exp_m = exp_m;
end

end
