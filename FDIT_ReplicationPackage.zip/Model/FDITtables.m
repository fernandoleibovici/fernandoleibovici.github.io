function x = FDITtables(wksp)

%% Workspace

m = wksp{1}.m;
sim = wksp{1}.sim;

m_L = wksp{1}.exp_m{1};
sim_L = wksp{1}.exp_sim{1};

m_H = wksp{1}.exp_m{2};
sim_H = wksp{1}.exp_sim{2};

%% Table 1: Parameterization

fprintf('\n');
disp('=========================');
disp('Table 1: Parameterization');  
disp('=========================');
disp('------------------------');
disp('Predetermined parameters');
disp('------------------------');
fprintf('Risk aversion (gamma)                  %8.0f \n',m.gamma);  
fprintf('Elasticity of substitution (sigma)     %8.0f \n',m.sigma);  
fprintf('Depreciation rate (delta)              %8.2f \n',m.delta);  
fprintf('Interest rate (r)                      %8.3f \n',m.r);
fprintf('Intermediate input shares (phi)        %8.2f %8.2f %8.2f %8.2f\n',[m.phi_int_vec(end) m.phi_int_vec(1:3)]);
fprintf('Final good shares (Phi)                %8.2f %8.2f %8.2f %8.2f\n',[m.phi_fin_vec(end) m.phi_fin_vec(1:3)]);
fprintf('Input-output matrix (Omega)            %8.2f %8.2f %8.2f %8.2f\n',[m.gamma_mat(end,end)' m.gamma_mat(1:3,end)']);
fprintf('                                       %8.2f %8.2f %8.2f %8.2f\n',[m.gamma_mat(end,1)' m.gamma_mat(1:3,1)']);
fprintf('                                       %8.2f %8.2f %8.2f %8.2f\n',[m.gamma_mat(end,2)' m.gamma_mat(1:3,2)']);
fprintf('                                       %8.2f %8.2f %8.2f %8.2f\n',[m.gamma_mat(end,3)' m.gamma_mat(1:3,3)']);
disp('--------------------');
disp('Estimated parameters');
disp('--------------------');
fprintf('Discount factor (beta)                 %8.3f \n',m.beta);  
fprintf('Borrowing constraint (theta)           %8.3f \n',m.theta);  
fprintf('Capital share: Sector L (alpha_L)      %8.3f \n',m.alpha_vec(1));  
fprintf('Capital share: Sector M (alpha_M)      %8.3f \n',m.alpha_vec(2)); 
fprintf('Capital share: Sector H (alpha_H)      %8.3f \n',m.alpha_vec(3)); 
fprintf('Fixed operation cost: Sector H (xi_H)  %8.3f \n',m.M1_vec(3)); 
fprintf('Iceberg trade cost: Sector L (tau_L)   %8.3f \n',m.tau_vec(1));  
fprintf('Iceberg trade cost: Sector M (tau_M)   %8.3f \n',m.tau_vec(2)); 
fprintf('Iceberg trade cost: Sector H (tau_H)   %8.3f \n',m.tau_vec(3)); 
fprintf('Fixed export cost: Sector L (Xi1_L)    %8.3f \n',m.F_vec(1));  
fprintf('Fixed export cost: Sector M (Xi1_M)    %8.3f \n',m.F_vec(2)); 
fprintf('Fixed export cost: Sector H (Xi1_H)    %8.3f \n',m.F_vec(3)); 
fprintf('Sunk export entry cost (Xi0)           %8.3f \n',m.Scost); 
fprintf('Productivity dispersion (sigma_z)      %8.3f \n',m.log_z_sigma); 
fprintf('Productivity persistence (rho_z)       %8.3f \n',m.log_z_rho); 
fprintf('Size of the rest of the world (ybar*)  %8.3f \n',m.Yrow/m.B); 
fprintf('=====================================\n');

%% Table 2: Moments

fprintf('\n');
disp('================');
disp('Table 2: Moments');  
disp('================');
fprintf('Moment                                    Data                 Model\n');
fprintf('--------------------------------------------------------------------\n');
fprintf('Average sales (age 5/age 1)            %8.3f             %8.3f\n',[1.568 mean(sim.avg_sales_age5_age1)]);  
fprintf('Credit/Value added                     %8.3f             %8.3f\n',[0.188 sim.ncredit_GDP]); 
fprintf('Capital stock/Wage bill                %8.3f             %8.3f\n',[4.848 sim.K_wagebill_ratio_withfixedcosts]); 
fprintf('Capital per worker (sector H/sector L) %8.3f             %8.3f\n',[7.229 sim.kn_med_HtoLratio]); 
fprintf('Capital per worker (sector M/sector L) %8.3f             %8.3f\n',[1.950 sim.kn_med_MtoLratio]); 
fprintf('# of workers (sector H/sector L)       %8.3f             %8.3f\n',[2.895 sim.n_med_HtoLratio]); 
fprintf('Exports/Sales: Sector L                %8.3f             %8.3f\n',[0.231 sim.XY_vec(1)]); 
fprintf('Exports/Sales: Sector M                %8.3f             %8.3f\n',[0.150 sim.XY_vec(2)]);
fprintf('Exports/Sales: Sector H                %8.3f             %8.3f\n',[0.279 sim.XY_vec(3)]);
fprintf('Share of exporters: Sector L           %8.3f             %8.3f\n',[0.161 sim.firms_share_x_vec(1)]); 
fprintf('Share of exporters: Sector M           %8.3f             %8.3f\n',[0.254 sim.firms_share_x_vec(2)]);
fprintf('Share of exporters: Sector H           %8.3f             %8.3f\n',[0.409 sim.firms_share_x_vec(3)]);
fprintf('Export exit rate                       %8.3f             %8.3f\n',[0.118 sim.xexit_rate]);
fprintf('Average sales (exporters/non-exporters)%8.3f             %8.3f\n',[8.258 sim.Xsales_NXsales]);
fprintf('Exit rate                              %8.3f             %8.3f\n',[0.119 sim.exit_rate_firms]);
fprintf('Absorption/World absorption            %8.5f             %8.5f\n',[0.00246 sim.Abs_WorldGDP]);
fprintf('===========================\n');

%% Table 3: Financial development and international trade

fprintf('\n');
disp('======================================================');
disp('Table 3: Financial development and international trade');  
disp('======================================================');
fprintf('                                       No credit          Baseline        High credit\n');
fprintf('A. Industry-level implications                                                       \n');
fprintf('-------------------------------------------------------------------------------------\n');
fprintf('Exports/Domestic sales, Sector L   %8.2f           %8.2f        %8.2f         \n',[sim_L.XD_vec(1) sim.XD_vec(1) sim_H.XD_vec(1)]); 
fprintf('Exports/Domestic sales, Sector M   %8.2f           %8.2f        %8.2f         \n',[sim_L.XD_vec(2) sim.XD_vec(2) sim_H.XD_vec(2)]);
fprintf('Exports/Domestic sales, Sector H   %8.2f           %8.2f        %8.2f         \n',[sim_L.XD_vec(3) sim.XD_vec(3) sim_H.XD_vec(3)]);
fprintf('Share of exporters, Sector L       %8.2f           %8.2f        %8.2f         \n',[sim_L.firms_share_x_vec(1) sim.firms_share_x_vec(1) sim_H.firms_share_x_vec(1)]); 
fprintf('Share of exporters, Sector M       %8.2f           %8.2f        %8.2f         \n',[sim_L.firms_share_x_vec(2) sim.firms_share_x_vec(2) sim_H.firms_share_x_vec(2)]);
fprintf('Share of exporters, Sector H       %8.2f           %8.2f        %8.2f         \n',[sim_L.firms_share_x_vec(3) sim.firms_share_x_vec(3) sim_H.firms_share_x_vec(3)]);
fprintf('Avg. sectoral productivity (H/L)   %8.2f           %8.2f        %8.2f         \n',[sim_L.zavg_sec(3)/sim_L.zavg_sec(1) sim.zavg_sec(3)/sim.zavg_sec(1) sim_H.zavg_sec(3)/sim_H.zavg_sec(1)]);
fprintf('Avg. sectoral productivity (M/L)   %8.2f           %8.2f        %8.2f         \n',[sim_L.zavg_sec(2)/sim_L.zavg_sec(1) sim.zavg_sec(2)/sim.zavg_sec(1) sim_H.zavg_sec(2)/sim_H.zavg_sec(1)]);
fprintf('=====================================================================================\n');
fprintf('B. Aggregate implications                                                            \n');
fprintf('-------------------------------------------------------------------------------------\n');
fprintf('Agg. credit/Agg. value added       %8.2f           %8.2f        %8.2f         \n',[sim_L.ncredit_GDP sim.ncredit_GDP sim_H.ncredit_GDP]); 
fprintf('Agg. exports/Agg. domestic sales   %8.2f           %8.2f        %8.2f         \n',[sim_L.X_D sim.X_D sim_H.X_D]);
fprintf('=====================================================================================\n');
fprintf('C. Prices                                                                            \n');
fprintf('-------------------------------------------------------------------------------------\n');
fprintf('Real wage (w/p)                    %8.2f           %8.2f        %8.2f         \n',[m_L.w/sim_L.P m.w/sim.P m_H.w/sim_H.P]/(m.w/sim.P)); 
fprintf('Price of intermediates (ph/p), NT  %8.2f           %8.2f        %8.2f         \n',[(sim_L.Pint_vec(4)/sim_L.P) sim.Pint_vec(4)/sim.P sim_H.Pint_vec(4)/sim_H.P]/(sim.Pint_vec(4)/sim.P)); 
fprintf('Price of intermediates (ph/p), L   %8.2f           %8.2f        %8.2f         \n',[(sim_L.Pint_vec(1)/sim_L.P) sim.Pint_vec(1)/sim.P sim_H.Pint_vec(1)/sim_H.P]/(sim.Pint_vec(1)/sim.P)); 
fprintf('Price of intermediates (ph/p), M   %8.2f           %8.2f        %8.2f         \n',[(sim_L.Pint_vec(2)/sim_L.P) sim.Pint_vec(2)/sim.P sim_H.Pint_vec(2)/sim_H.P]/(sim.Pint_vec(2)/sim.P)); 
fprintf('Price of intermediates (ph/p), H   %8.2f           %8.2f        %8.2f         \n',[(sim_L.Pint_vec(3)/sim_L.P) sim.Pint_vec(3)/sim.P sim_H.Pint_vec(3)/sim_H.P]/(sim.Pint_vec(3)/sim.P)); 
fprintf('Sectoral price (pj/p), NT          %8.2f           %8.2f        %8.2f         \n',[(sim_L.Psect_vec(4)/sim_L.P) sim.Psect_vec(4)/sim.P sim_H.Psect_vec(4)/sim_H.P]/(sim.Psect_vec(4)/sim.P)); 
fprintf('Sectoral price (pj/p), L           %8.2f           %8.2f        %8.2f         \n',[(sim_L.Psect_vec(1)/sim_L.P) sim.Psect_vec(1)/sim.P sim_H.Psect_vec(1)/sim_H.P]/(sim.Psect_vec(1)/sim.P)); 
fprintf('Sectoral price (pj/p), M           %8.2f           %8.2f        %8.2f         \n',[(sim_L.Psect_vec(2)/sim_L.P) sim.Psect_vec(2)/sim.P sim_H.Psect_vec(2)/sim_H.P]/(sim.Psect_vec(2)/sim.P)); 
fprintf('Sectoral price (pj/p), H           %8.2f           %8.2f        %8.2f         \n',[(sim_L.Psect_vec(3)/sim_L.P) sim.Psect_vec(3)/sim.P sim_H.Psect_vec(3)/sim_H.P]/(sim.Psect_vec(3)/sim.P)); 
fprintf('Real exchange rate (p*/p)          %8.2f           %8.2f        %8.2f         \n',[m_L.Prow/sim_L.P m.Prow/sim.P m_H.Prow/sim_H.P]/(m.Prow/sim.P)); 
fprintf('=====================================================================================\n');

%% Table 6: Industry-level implications, model vs. data

fprintf('\n');
disp('====================================================');
disp('Table 6: Industry-level implications, model vs. data');  
disp('====================================================');
fprintf('                Data                             Model         \n');
fprintf('-------------------------------------------------------------\n');
fprintf('Sector L        (Compute using Stata codes)  %8.2f \n',[log(sim_H.XD_vec(1))-log(sim_L.XD_vec(1))]); 
fprintf('Sector M        (Compute using Stata codes)  %8.2f \n',[log(sim_H.XD_vec(2))-log(sim_L.XD_vec(2))]); 
fprintf('Sector H        (Compute using Stata codes)  %8.2f \n',[log(sim_H.XD_vec(3))-log(sim_L.XD_vec(3))]); 
fprintf('=============================================================\n');

%% End

end
