%Process to discretize:
%y_{t+1} = (1-rho)*mu + rho*y_{t} + eps_{t}
%where eps_{t}~N(0,sigma_e)

%Parameters:
%c = number of standard deviations away from the mean of lowest/highest value
%n = number of grid points

%Output:
%z = vector of values of states
%P = matrix of transition probabilities
%pi = stationary distribution
function [z,P,pi] = AR1_tauchen(n,c,rho,sigma_e,mu,z_power)

%Standard deviation of stationary process y (and discrete process z)
    sigma_z = sigma_e/sqrt(1-rho^2);

%Solve for values of discrete state space 
    z_1 = mu - c*sigma_z; 
    z_end = mu + c*sigma_z;
    z = (linspace(0,1,n).^z_power).*(z_end-z_1) + z_1;
    z = z';
    
%Construct midpoints m(i), i=1...n-1
    m = (z(2:n)+z(1:n-1))/2;

%Transition matrix    
    P = zeros(n,n);
    for i=1:n
        P(i,1) = normcdf((m(1)-(1-rho)*mu-rho*z(i))/sigma_e);
           for j=2:n-1
                P(i,j) = normcdf((m(j)-(1-rho)*mu-rho*z(i))/sigma_e)-normcdf((m(j-1)-(1-rho)*mu-rho*z(i))/sigma_e);

           end
        P(i,n) = 1-normcdf((m(n-1)-(1-rho)*mu-rho*z(i))/sigma_e);
    end

%Obtain Limiting distribution
%pi'*P=pi' => P'*pi=pi => (P'-I)*pi=0
    evalc('[V,D]=eigs(P'',1)');
    pi = V/sum(V); %Limiting distribution (eigenvector associated to eigenvalue = 1, the largest)




